package stock;



import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

//재고추가 다이얼로그 부분
class stockAddManege extends JDialog implements ActionListener {
	JTextField tfBookname, tfWriter, tfPrice, tfNumber;
	JLabel lblBookname, lblWriter, lblPrice, lblJanre, lblNumber, lblStock;
	JButton save;
	JComboBox cbJanre;
	JSpinner jspStock;
	String[] str;
	String[] janreList = { " ", "소설", "수필", "인문학", "자기계발", "시" };
	StockAdd sa;
	int i;

	public stockAddManege(StockAdd sa) {

		this.sa = sa;
		setTitle("追加");
		setSize(250, 300);
		JPanel pnl = new JPanel();
		JPanel btnpnl = new JPanel();
		// 패널 생성
		pnl.setLayout(new GridLayout(6, 0));

		// 텍스트필드 생성
		tfBookname = new JTextField(20);
		tfWriter = new JTextField(20);
		tfPrice = new JTextField(20);
		tfNumber = new JTextField(20);
		// 콤보박스 생성
		cbJanre = new JComboBox(janreList);
		cbJanre.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		// 수량 스피너 생성
		SpinnerNumberModel stockNum = new SpinnerNumberModel(5, 0, 20, 1);
		jspStock = new JSpinner(stockNum);

		// 라벨 생성
		lblBookname = new JLabel("タイトル", JLabel.RIGHT);
		lblBookname.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblWriter = new JLabel("著者", JLabel.RIGHT);
		lblWriter.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblPrice = new JLabel("値段", JLabel.RIGHT);
		lblPrice.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblJanre = new JLabel("ジャンル", JLabel.RIGHT);
		lblJanre.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblNumber = new JLabel("図書管理ナンバー", JLabel.RIGHT);
		lblNumber.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblStock = new JLabel("数", JLabel.RIGHT);
		lblStock.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		save = new JButton("저장");
		save.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		save.addActionListener(this);

		// 패널에 텍스트필드, 라벨 추가
		pnl.add(lblBookname);
		pnl.add(tfBookname);
		pnl.add(lblWriter);
		pnl.add(tfWriter);
		pnl.add(lblPrice);
		pnl.add(tfPrice);
		pnl.add(lblJanre);
		pnl.add(cbJanre);
		pnl.add(lblNumber);
		pnl.add(tfNumber);
		pnl.add(lblStock);
		pnl.add(jspStock);
		btnpnl.add(save);
		this.add(pnl, "Center");
		this.add(btnpnl, "South");

		setLocationRelativeTo(null);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == save) {
			// 값 부모클래스에 넘겨주기
			String[] str = new String[6];

			str[0] = tfBookname.getText();
			str[1] = tfWriter.getText();
			str[2] = tfPrice.getText();
			str[3] = (String) cbJanre.getSelectedItem();
			str[4] = tfNumber.getText();
			str[5] = (jspStock.getValue()).toString();
			// 부모클래스의 생성자 이용
			sa.setData(str);
			this.dispose();
		}
	}
}

// 도서 정보 변경
class InfoChange extends JDialog implements ActionListener {
	JTable table;
	JTextField tfBookname, tfWriter, tfPrice, tfNumber;
	JLabel lblBookname, lblWriter, lblPrice, lblJanre, lblNumber, lblStock;
	JButton save;
	JComboBox cbJanre;
	JSpinner jspStock;
	String[] str;
	String[] janreList = { " ", "소설", "수필", "인문학", "자기계발", "시" };
	StockAdd sa;
	int i, selectedRow;

	public InfoChange(StockAdd sa) {

		this.sa = sa;
		this.table = sa.table;
		setTitle("情報変更");
		setSize(250, 300);
		JPanel pnl = new JPanel();
		JPanel btnpnl = new JPanel();
		// 패널 생성
		pnl.setLayout(new GridLayout(6, 0));
		// 텍스트필드 생성
		tfBookname = new JTextField(20);
		tfWriter = new JTextField(20);
		tfPrice = new JTextField(20);
		tfNumber = new JTextField(20);
		// 콤보박스 생성
		cbJanre = new JComboBox(janreList);
		cbJanre.setFont(new Font("맑은 고딕", Font.PLAIN, 12));

		// 라벨 생성
		lblBookname = new JLabel("タイトル", JLabel.RIGHT);
		lblBookname.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblWriter = new JLabel("著者", JLabel.RIGHT);
		lblWriter.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblPrice = new JLabel("値段", JLabel.RIGHT);
		lblPrice.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblJanre = new JLabel("ジャンル", JLabel.RIGHT);
		lblJanre.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblNumber = new JLabel("図書管理ナンバー", JLabel.RIGHT);
		lblNumber.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblStock = new JLabel("数", JLabel.RIGHT);
		lblStock.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		save = new JButton("저장");
		save.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		save.addActionListener(this);

		// 수량 스피너 생성
		selectedRow = table.getSelectedRow();
		// 선택한 Row의 6번째(수량)값을 스피너에 넣어주는 부분
		int i = Integer.parseInt((String) table.getValueAt(selectedRow, 5));
		SpinnerNumberModel stockNum = new SpinnerNumberModel(i, 0, 20, 1);
		jspStock = new JSpinner(stockNum);

		// 패널에 텍스트필드, 라벨 추가
		pnl.add(lblBookname);
		pnl.add(tfBookname);
		pnl.add(lblWriter);
		pnl.add(tfWriter);
		pnl.add(lblPrice);
		pnl.add(tfPrice);
		pnl.add(lblJanre);
		pnl.add(cbJanre);
		pnl.add(lblNumber);
		pnl.add(tfNumber);
		pnl.add(lblStock);
		pnl.add(jspStock);
		btnpnl.add(save);
		// 다이얼로그에 누른 열의 값 추가
		tfBookname.setText((String) table.getValueAt(selectedRow, 0));
		tfWriter.setText((String) table.getValueAt(selectedRow, 1));
		tfPrice.setText((String) table.getValueAt(selectedRow, 2));
		cbJanre.setSelectedItem((String) table.getValueAt(selectedRow, 3));
		tfNumber.setText((String) table.getValueAt(selectedRow, 4));
		this.add(pnl, "Center");
		this.add(btnpnl, "South");

		setLocationRelativeTo(null);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == save) {
			// 값 부모클래스에 넘겨주기
			String[] str = new String[6];

			str[0] = tfBookname.getText();
			str[1] = tfWriter.getText();
			str[2] = tfPrice.getText();
			str[3] = (String) cbJanre.getSelectedItem();
			str[4] = tfNumber.getText();
			str[5] = (jspStock.getValue()).toString();
			// 부모클래스의 생성자 이용
			sa.ChangeData(str);
			this.dispose();
		}
	}
}

// 메인
public class StockAdd extends JPanel implements ActionListener, MouseListener {
	private JButton btnbookManagement;// 도서관리조회
	private JButton btnstockAdd;// 도서재고등록
	private JButton btnBookSell;// 도서판매
	private JButton btnsalesManagement;// 매출관리
	private JButton btnManagerManagement;// 담당자관리
	// 로그아웃버튼
	private JButton btnLogOut;// 전역변수
	// 기능버튼 재고추가,저장,열 삭제
	JButton btnInfo, btnAdd, btnSave, btnDel;
	// 저장용
	PrintWriter pw;
	FileWriter fw;
	BufferedReader inputStream;
	private String l;
	// 테이블 변수
	JTable table;
	DefaultTableModel model;
	String header[] = { "タイトル", "著者", "値段", "ジャンル", "図書管理ナンバー", "数" };
	String contents[][] = {};
	// 값 입력용 변수
	String[] str;
	String[] bring = new String[6];
	int i;
	int selectedRow;
	int row;

	public StockAdd() {

		// 본문 설정
		this.setLayout(new BorderLayout());
		setSize(1024, 768);
		JPanel wpnl = new JPanel(new GridLayout(5, 0, 30, 30));
		wpnl.setBorder(BorderFactory.createEmptyBorder(30, 10, 30, 10));

		// 테이블 생성
		JPanel Cpnl = new JPanel();
		model = new DefaultTableModel(contents, header) {
			// 테이블 편집 불가 설정
			public boolean isCellEditable(int i, int c) {
				return false;
			}
		};
		table = new JTable(model);
		table.addMouseListener(this);
		JScrollPane sp = new JScrollPane(table);
		sp.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
		sp.setBorder(new TitledBorder(new LineBorder(Color.blue, 1), "재고관리"));
		sp.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		sp.setPreferredSize(new Dimension(800, 600));
		Cpnl.add(sp);

		// 버튼 패널 생성
		JPanel btnPnl = new JPanel();
		btnPnl.setLayout(new GridLayout(0, 4, 30, 30));
		btnPnl.setBorder(BorderFactory.createEmptyBorder(00, 30, 0, 30));
		btnAdd = new JButton("追加");
		btnAdd.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnAdd.addActionListener(this);
		btnAdd.setPreferredSize(new Dimension(160, 50));
		btnSave = new JButton("セーブ");
		btnSave.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnSave.addActionListener(this);
		btnSave.setPreferredSize(new Dimension(160, 50));
		btnDel = new JButton("列抜き");
		btnDel.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnDel.addActionListener(this);
		btnDel.setPreferredSize(new Dimension(160, 50));
		btnInfo = new JButton("図書探す");
		btnInfo.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnInfo.addActionListener(this);
		btnInfo.setPreferredSize(new Dimension(160, 50));
		btnPnl.add(btnInfo);
		btnPnl.add(btnAdd);
		btnPnl.add(btnSave);
		btnPnl.add(btnDel);
		Cpnl.add(btnPnl, "South");

		add(Cpnl, "Center");

		setVisible(true);
	}

	// 도서 정보 추가
	void setData(String[] str) {
		// 다이얼로그에서 가져온 값 table(model)에 추가하기

		bring[0] = str[0];
		bring[1] = str[1];
		bring[2] = str[2];
		bring[3] = str[3];
		bring[4] = str[4];
		bring[5] = str[5];
		
		boolean isExist=false;

		for (int i = 0; i < table.getRowCount(); i++) {
			if (table.getValueAt(i, 4).equals(bring[4])) {
				isExist=true;
				break;
			}
		}
		
		if(isExist){
			JOptionPane.showMessageDialog(this, "IDを確認してください");
		}else{
			model.addRow(bring);
		}
	}

	// 도서 정보 변경
	void ChangeData(String[] str) {
		selectedRow = table.getSelectedRow();
		bring[0] = str[0];
		bring[1] = str[1];
		bring[2] = str[2];
		bring[3] = str[3];
		bring[4] = str[4];
		bring[5] = str[5];

		model.fireTableDataChanged();
		table.setValueAt(str[0], selectedRow, 0);
		table.setValueAt(str[1], selectedRow, 1);
		table.setValueAt(str[2], selectedRow, 2);
		table.setValueAt(str[3], selectedRow, 3);
		table.setValueAt(str[4], selectedRow, 4);
		table.setValueAt(str[5], selectedRow, 5);
		revalidate();
		repaint();

	}

	// 액션리스너
	public void actionPerformed(ActionEvent e) {
		// 도서정보+재고 입력
		if (e.getSource() == btnInfo) {
			try {
				// 불러오기
				File file = new File("BookList.txt");
				int i = 0;
				try {
					inputStream = new BufferedReader(new FileReader(file.toString()));
					l = "";
					String[] str = new String[10000];

					while ((l = inputStream.readLine()) != null) {
						str[i] = l;
						i++;
					}
					String[] spl = new String[6];

					for (int j = 0; j < i; j++) {
						spl = str[j].split("/");
						for (int k = 0; k < spl.length; k++) {
						}
						model.addRow(spl);
					}
					repaint();
				} catch (IOException e1) {
					// TODO 자동 생성된 catch 블록
					e1.printStackTrace();
				}

			} finally {
				try {

					if (pw != null) {
						pw.close();
					}

					if (fw != null) {
						fw.close();
					}
				} catch (IOException e2) {
					e2.printStackTrace();
				}
			}
		} else if (e.getSource() == btnAdd) {

			new stockAddManege(this);

		}
		// 수정사항 메모장에 저장(미완성)
		else if (e.getSource() == btnSave) {
			try {
				File file = new File("BookList.txt");
				// 파일 가져오기 -> 입력하기

				fw = new FileWriter(file);

				pw = new PrintWriter(fw);

				for (int i = 0; i < table.getRowCount(); ++i) { // 내용 :
					// 행이 끝날때 엔터
					for (int j = 0; j < table.getColumnCount(); j++) {

						pw.write((table.getValueAt(i, j).toString()));

						pw.write("/");
					}
					pw.println("");
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} finally {

				pw.close();
			}

			// 테이블에서 열 삭제
		} else if (e.getSource() == btnDel) {
			selectedRow = table.getSelectedRow();
			model.removeRow(selectedRow);
		}
	}

	public static void main(String[] args) {
		// 자기생성자
		new StockAdd();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2) {
			new InfoChange(this);
		}
	}
	public void mouseEntered(MouseEvent arg0) {}
	public void mouseExited(MouseEvent arg0) {}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}

}