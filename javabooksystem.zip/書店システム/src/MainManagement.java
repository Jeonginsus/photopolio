

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import BookManagement.BookManagement;
import HumanResource.BSManagerment;
import SalesManagement.SalesManagementMain;
import sell.SellingControl;
import stock.StockAdd;

public class MainManagement extends JFrame implements ActionListener {

	SellingControl SelCon;
	StockAdd stockAdd;
	BSManagerment BSM;
	SalesManagementMain smm;
	BookManagement bookManagement;
	private JPanel pnlCenter;
	private JButton btnbookManagement;// 도서관리조회(임의값)
	private JButton btnstockAdd;// 도서재고등록
	private JButton btnBookSell;// 도서판매(임의값)
	private JButton btnsalesManagement;// 매출관리(임의값)
	private JButton btnManagerManagement;// 담당자관리(임의값)
	private JButton btnLogOut;

	public MainManagement() {
		setSize(1024, 768);
		setTitle("販売");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		pnlCenter = new JPanel(new BorderLayout());
		SelCon = new SellingControl();
		pnlCenter.add(SelCon);
		add(pnlCenter, "Center");

		JPanel pnlTopbar = new JPanel(new BorderLayout()){
			 public void paintComponent(Graphics g) {
				 ImageIcon image = new ImageIcon("FinalTitle.jpg");
				    g.drawImage(image.getImage(), 0, 0, null);
			 }
		};

		btnLogOut = new JButton("ログアウト");
		btnLogOut.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnLogOut.addActionListener(this);
		
		pnlTopbar.add(btnLogOut, "East");
		pnlTopbar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		this.add(pnlTopbar, "North");

		JPanel pnlWestSide = new JPanel(new GridLayout(5, 0, 30, 30));
		pnlWestSide.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));

		btnbookManagement = new JButton("サーチ");
		btnbookManagement.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnbookManagement.addActionListener(this);
		btnstockAdd = new JButton("同録");
		btnstockAdd.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnstockAdd.addActionListener(this);
		btnBookSell = new JButton("販売");
		btnBookSell.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnBookSell.addActionListener(this);
		btnsalesManagement = new JButton("売上");
		btnsalesManagement.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnsalesManagement.addActionListener(this);
		btnManagerManagement = new JButton("管理者");
		btnManagerManagement.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnManagerManagement.addActionListener(this);

		btnBookSell.setEnabled(false);

		// 왼쪽 버튼 위치
		pnlWestSide.add(btnbookManagement);
		pnlWestSide.add(btnstockAdd);
		pnlWestSide.add(btnBookSell);
		pnlWestSide.add(btnsalesManagement);
		pnlWestSide.add(btnManagerManagement);

		this.add(pnlWestSide, "West");
		setVisible(true);
	}

	public static void main(String[] args) {
		new MainManagement();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnLogOut) {
			new Home();
			this.dispose();
		} else if (e.getSource() == btnbookManagement) {

			setTitle("サーチ");
			btnbookManagement.setEnabled(false);
			btnstockAdd.setEnabled(true);
			btnBookSell.setEnabled(true);
			btnsalesManagement.setEnabled(true);
			btnManagerManagement.setEnabled(true);

			remove(pnlCenter);
			pnlCenter = new JPanel(new BorderLayout());
			bookManagement = new BookManagement();
			pnlCenter.add(bookManagement);
			add(pnlCenter, "Center");
			revalidate();
			repaint();
		} else if (e.getSource() == btnstockAdd) {

			setTitle("同録");
			btnbookManagement.setEnabled(true);
			btnstockAdd.setEnabled(false);
			btnBookSell.setEnabled(true);
			btnsalesManagement.setEnabled(true);
			btnManagerManagement.setEnabled(true);

			remove(pnlCenter);
			pnlCenter = new JPanel(new BorderLayout());
			stockAdd = new StockAdd();
			pnlCenter.add(stockAdd);
			add(pnlCenter, "Center");
			revalidate();
			repaint();

		} else if (e.getSource() == btnBookSell) {

			setTitle("販売");
			remove(pnlCenter);
			btnbookManagement.setEnabled(true);
			btnstockAdd.setEnabled(true);
			btnBookSell.setEnabled(false);
			btnsalesManagement.setEnabled(true);
			btnManagerManagement.setEnabled(true);

			pnlCenter = new JPanel(new BorderLayout());
			SelCon = new SellingControl();
			pnlCenter.add(SelCon);
			add(pnlCenter, "Center");
			revalidate();
			repaint();

		} else if (e.getSource() == btnsalesManagement) {

			setTitle("売上");
			btnbookManagement.setEnabled(true);
			btnstockAdd.setEnabled(true);
			btnBookSell.setEnabled(true);
			btnsalesManagement.setEnabled(false);
			btnManagerManagement.setEnabled(true);
			
			remove(pnlCenter);
			pnlCenter = new JPanel(new BorderLayout());
			smm = new SalesManagementMain();
			pnlCenter.add(smm);
			add(pnlCenter, "Center");
			revalidate();
			repaint();

		} else if (e.getSource() == btnManagerManagement) {

			setTitle("管理者");
			btnbookManagement.setEnabled(true);
			btnstockAdd.setEnabled(true);
			btnBookSell.setEnabled(true);
			btnsalesManagement.setEnabled(true);
			btnManagerManagement.setEnabled(false);
			
			remove(pnlCenter);
			pnlCenter = new JPanel(new BorderLayout());
			BSM = new BSManagerment();
			pnlCenter.add(BSM);
			add(pnlCenter, "Center");
			revalidate();
			repaint();

		}
	}
}
