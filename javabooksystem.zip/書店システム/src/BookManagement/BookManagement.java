package BookManagement;



import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import DataModel.FileToValue;

public class BookManagement extends JPanel implements ActionListener {
	JTable tableUser;
	JButton btnLookUp,btnbookManagement,btnstockAdd,btnBookSell,btnsalesManagement,btnManagerManagement;
	JComboBox combo;
	JTextField tfSearch;
	JScrollPane sp;
	JPanel pnlNorth, pnlCenter, pnlCenter2;
	String header[] = { "タイトル", "著者", "値段", "ジャンル", "図書管理ナンバー", "数"  };
	String contents[][] = {};
	
	String str[] = {"タイトル","著者","図書管理ナンバー"};
	DefaultTableModel model;
	
	
	
	
	public BookManagement() {
		setLayout(new BorderLayout());
		setBorder(new TitledBorder(new LineBorder(Color.blue, 1), "도서조회"));
		JLabel labelSearch = new JLabel("検索方法");
		labelSearch.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		combo = new JComboBox(str);
		tfSearch = new JTextField(20);
		btnLookUp = new JButton("探す");
		btnLookUp.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnLookUp.addActionListener(this);
		pnlCenter2 = new JPanel(new FlowLayout(FlowLayout.RIGHT)); 
		pnlCenter2.add(labelSearch);
		pnlCenter2.add(combo);
		pnlCenter2.add(tfSearch);
		pnlCenter2.add(btnLookUp);

		model = new DefaultTableModel(contents, header){

			public boolean isCellEditable(int i, int c) {
				return false;
			}
		};
		tableUser = FileToValue.makeTable("BookList.txt", model);
		sp = new JScrollPane(tableUser);
		sp.setBorder(BorderFactory.createEmptyBorder(3, 5, 5, 5));
		
		System.out.println(tableUser.getRowCount());

		pnlCenter = new JPanel(new BorderLayout());
		 
		pnlCenter.add(pnlCenter2, "North");
		pnlCenter.add(sp, "Center");
		this.add(pnlCenter);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btnLookUp){ //조회기능 (검색조건을 콤보박스에서 선택후 텍스트필드에 검색해서 찾기)			
			//model = FileToValue.searchModel("BookList.txt", model, combo.getSelectedItem(), tfSearch.getText());
			FileToValue.searchModel("BookList.txt", model, combo.getSelectedItem(), tfSearch.getText());
		}
	}
}