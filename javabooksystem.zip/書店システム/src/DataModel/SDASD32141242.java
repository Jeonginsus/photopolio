package DataModel;


import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class SDASD32141242 {
	public SDASD32141242(){
		JFrame frame = new JFrame();
	JPanel pl = new JPanel(){
		 public void paintComponent(Graphics g) {
			 ImageIcon image = new ImageIcon("/�ڸ���/FinalTitle.jpg");
			    g.drawImage(image.getImage(), 0, 0, null);
		 }
	};
	frame.add(pl);
	frame.setSize(300,300);
	frame.setVisible(true);
	frame.setDefaultCloseOperation(3);
	}
public static void main (String args[]) {
	new SDASD32141242();
	
}
}
