package DataModel;

public class SalesMountVO {
	
	private String bookName;
	private String author;
	private String primaryKey;
	private int salesMount;
	
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPrimaryKey() {
		return primaryKey;
	}
	public void setPrimaryKey(String primaryKey) {
		this.primaryKey = primaryKey;
	}
	public int getSalesMount() {
		return salesMount;
	}
	public void setSalesMount(int salesMount) {
		this.salesMount = salesMount;
	}
	@Override
	public String toString() {
		return "SalesMountVO [bookName=" + bookName + ", author=" + author + ", primaryKey=" + primaryKey
				+ ", salesMount=" + salesMount + "]";
	}
	
	
	
	
	

}
