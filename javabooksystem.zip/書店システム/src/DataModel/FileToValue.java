package DataModel;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class FileToValue {
	
	
	public static JTable makeTable(String file, DefaultTableModel model){
		JTable tbl = null;	//초기값	
		try {
			BufferedReader br = new BufferedReader(new FileReader("BookList.txt"));
			String l = null;
			while((l=br.readLine()) != null){ //널이 아닐때 
				String[] s = l.split("/");
				model.addRow(s);
			}
			tbl = new JTable(model);
		} catch (FileNotFoundException e) {
			// TODO 자동 생성된 catch 블록
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 자동 생성된 catch 블록
			e.printStackTrace();
		}
		
		return tbl;
	}
	
	public static DefaultTableModel searchModel(String file, DefaultTableModel model, Object searchItem, String searchValue){		
		try {			
			int culumn = 0;
			if(searchItem.toString().equals("タイトル")){
				culumn = 0;
			}else if(searchItem.toString().equals("著者")){
				culumn = 1;
			}else if(searchItem.toString().equals("図書管理ナンバー")){
				culumn = 4;
			}
			model.setNumRows(0);// 모델 초기화
			
			BufferedReader br = new BufferedReader(new FileReader(file));
			String l = null;
			while((l=br.readLine()) != null){
				String[] s = l.split("/");
				if(s[culumn].indexOf(searchValue) != -1){// 전체 문자열에서 찾는 글자가 있다면
					model.addRow(s);
				}
			}			
		} catch (FileNotFoundException e) {
			// TODO 자동 생성된 catch 블록
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 자동 생성된 catch 블록
			e.printStackTrace();
		}
		
		return model;//이메서드의 결과
	}
}