package DataModel;

public class DataVO {
	
	private String bookName;
	private String author;
	private int bookPrice;

	private String genre;
	private int primaryKey;
	
	private String year;
	private String month;
	private String day;
	
	
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public int getPrimaryKey() {
		return primaryKey;
	}
	public void setPrimaryKey(int primaryKey) {
		this.primaryKey = primaryKey;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	
	
	@Override
	public String toString() {
		return "DataVO [bookName=" + bookName + ", author=" + author + ", bookPrice=" + bookPrice + ", genre=" + genre
				+ ", primaryKey=" + primaryKey + ", year=" + year + ", month=" + month + ", day=" + day + "]";
	}
}
