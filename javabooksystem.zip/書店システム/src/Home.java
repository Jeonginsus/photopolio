

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import DataModel.FileToValue;


class LoginScreen2 extends JDialog implements ActionListener{
	JPanel pnlCenter;
	JTextField tfId,tfPw;
	JButton btnLogin;
	Home ste;
	BufferedReader br;
	
	public LoginScreen2(Home ste) {
		super(ste,true);
		this.ste = ste;
		this.setSize(300,250);
		this.setTitle("login");
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		JLabel labelLogin = new JLabel("管理者ログイン");
		labelLogin.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		this.add(labelLogin,"Center");
				
		
		JLabel lbId = new JLabel("ID");	
		lbId.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		tfId = new JTextField(15);
		JLabel lbPw = new JLabel("PW");	
		lbPw.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		tfPw = new JTextField(15);
	
		
		JPanel pnlCenter = new JPanel(new GridLayout(2,0,5,30));
		pnlCenter.setBorder(BorderFactory.createEmptyBorder(40, 10, 40, 10));
		pnlCenter.add(lbId);
		pnlCenter.add(tfId);
		pnlCenter.add(lbPw);
		pnlCenter.add(tfPw);
		this.add(pnlCenter);
		
		JPanel btnpnl = new JPanel();
		btnLogin = new JButton("ログイン");
		btnLogin.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnLogin.addActionListener(this);
		btnpnl.add(btnLogin);
		this.add(btnpnl,"South");
		this.setVisible(true);
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		//파일 불러와서 1.2컬럼에 tfId,tfPw가 있으면 로그인되게.  
		File file = new File("Manager.txt");
		try {
			br = new BufferedReader(new FileReader(file));
			String l = null;
			String match=null;
			while((l=br.readLine()) != null) {
				System.out.println(l);
				String[] s = l.split("/");
						
				if(s[1].equals(tfId.getText())){
					match=l;  //아이디가 일치하는게 있으면 그 줄을 match에 넣어라
					if(s[2].equals(tfPw.getText())){
						
						JOptionPane.showMessageDialog(this, "ログインしました。");
						System.out.println("디버깅용 : 로그인 성공 ");
						dispose();
						new MainManagement();
						ste.dispose();
					}
				}
			}
				if(match == null){
					JOptionPane.showMessageDialog(this, "IDを確認してください。");
				}else{
					if(!tfPw.getText().equals(match.split("/")[2])){
						JOptionPane.showMessageDialog(this, "PWを確認してください。");
					}
				}
				
				System.out.println(match);
	
		} catch (Exception e2) {
			// TODO: handle exception
		} 
	}
	
}

public class Home extends JFrame implements ActionListener,MouseListener {
	JTable tableUser;
	JButton btnLogin, btnLookUp,btnbookManagement,btnstockAdd,btnBookSell,btnsalesManagement,btnManagerManagement;
	JComboBox combo;
	JTextField tfSearch;
	JScrollPane sp;
	JPanel pnlNorth, pnlCenter, pnlCenter2;
	String header[] = { "タイトル", "著者", "値段", "ジャンル", "図書管理ナンバー", "数" };
	String contents[][] = {};
	
	String str[] = {"タイトル","著者","図書管理ナンバー"};
	DefaultTableModel model;
	private BufferedReader inputStream;
	
	
	
	
	public Home() {
		this.setSize(1024, 768);
		this.setDefaultCloseOperation(3);

		pnlNorth = new JPanel(new FlowLayout(FlowLayout.RIGHT));// FlowLayout.RIGHT 오른쪽으로 붙여라
		btnLogin = new JButton("管理者ログイン");
		btnLogin.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnLogin.addActionListener(this);
		pnlNorth.add(btnLogin);
		this.add(pnlNorth, "North");

		JLabel labelSearch = new JLabel("検索方法");
		labelSearch.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		combo = new JComboBox(str);
		tfSearch = new JTextField(20);
		btnLookUp = new JButton("探す");
		btnLookUp.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnLookUp.addActionListener(this);
		pnlCenter2 = new JPanel(new FlowLayout(FlowLayout.RIGHT)); 
		pnlCenter2.add(labelSearch);
		pnlCenter2.add(combo);
		pnlCenter2.add(tfSearch);
		pnlCenter2.add(btnLookUp);

		model = new DefaultTableModel(contents, header){

			public boolean isCellEditable(int i, int c) {
				return false;
			}
		};
		tableUser = FileToValue.makeTable("BookList.txt", model); 
		tableUser.addMouseListener(this);
		sp = new JScrollPane(tableUser);
		sp.setBorder(BorderFactory.createEmptyBorder(3, 5, 5, 5));
		
		System.out.println(tableUser.getRowCount());

		pnlCenter = new JPanel(new BorderLayout());
		 
		pnlCenter.add(pnlCenter2, "North");
		pnlCenter.add(sp, "Center");
		this.add(pnlCenter);
		
		this.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==btnLogin){
			new LoginScreen2(this);
		}else if(e.getSource()==btnLookUp){ //조회기능 (검색조건을 콤보박스에서 선택후 텍스트필드에 검색해서 찾기)			
			model = FileToValue.searchModel("BookList.txt", model, combo.getSelectedItem(), tfSearch.getText());
		}
	}
	public void mouseClicked(MouseEvent e) {
		if(e.getClickCount()==2){
			JOptionPane.showMessageDialog(null, "추후 개발예정입니다", "메세지",JOptionPane.ERROR_MESSAGE);
		}
	}

	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	
	public static void main(String[] args) {
		new Home();
	}
}