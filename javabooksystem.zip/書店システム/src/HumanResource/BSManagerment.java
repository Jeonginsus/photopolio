package HumanResource;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class BSManagerment extends JPanel implements ActionListener,MouseListener{
	JTable table;
	JButton btnLookup;
	JButton btnStock;
	JButton btnSale;
	JButton btnSaleManagement;
	JButton btnManager;
	JButton btnAddManager;
	JButton btnDeleteManager;
	JButton btnCommit;
	BufferedReader inputStream = null;
	PrintWriter outputStream = null;
	String l;
	String header[] = {"名前","ID","PW","その他"};
	String content[][] = {}; 
	DefaultTableModel model;

	JLabel lbName;
	JLabel lbNo;
	JLabel lbPw;
	JLabel lbMemo;
	JTextField txtName;
	JTextField txtNo;
	JTextField txtPw;
	JTextField txtMemo;
	
	
	public BSManagerment(){
		JPanel pnlLeft = new JPanel(new GridLayout(0,1));
		JPanel pnlBottom = new JPanel(new GridLayout(0,2,20,20));
		JPanel pnlMain = new JPanel(new BorderLayout());
		JPanel pnlLeftSide = new JPanel(new GridLayout(0,2));
		JPanel pnlRightSide = new JPanel(new GridLayout(0,3,20,20));
		
		setLayout(new BorderLayout());
		setBorder(new TitledBorder(new LineBorder(Color.blue, 1), "管理者"));
		model = new DefaultTableModel(content,header);
		table = new JTable(model);
		JScrollPane sp = new JScrollPane(table);

		
		btnLookup = new JButton("探す");
		btnLookup.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnStock = new JButton("同録");
		btnStock.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnSale = new JButton("販売");
		btnSale.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnSaleManagement = new JButton("売上");
		btnSaleManagement.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnManager = new JButton("管理");
		btnManager.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnAddManager = new JButton("追加");
		btnAddManager.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnDeleteManager  = new JButton("消す");
		btnDeleteManager.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnCommit = new JButton("確認");
		btnCommit.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		
		lbName = new JLabel("名前 : ");
		lbName.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txtName = new JTextField(10);
		lbNo = new JLabel("ナンバー : ");
		lbNo.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txtNo = new JTextField(10);
		lbPw  = new JLabel("PW : ");
		lbPw.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txtPw = new JTextField(10);
		lbMemo = new JLabel("その他 : ");
		lbMemo.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txtMemo = new JTextField(10);
		
		
		btnAddManager.addActionListener(this);
		btnCommit.addActionListener(this);
		btnDeleteManager.addActionListener(this);
		table.addMouseListener(this);
		pnlRightSide.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		pnlLeftSide.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));


		pnlLeftSide.add(lbName);
		pnlLeftSide.add(txtName);
		pnlLeftSide.add(lbNo);
		pnlLeftSide.add(txtNo);
		pnlLeftSide.add(lbPw);
		pnlLeftSide.add(txtPw);
		pnlLeftSide.add(lbMemo);
		pnlLeftSide.add(txtMemo);
		pnlRightSide.add(btnAddManager);
		pnlRightSide.add(btnDeleteManager);
		pnlRightSide.add(btnCommit);
		pnlBottom.add(pnlLeftSide);
		pnlBottom.add(pnlRightSide,"East");
		pnlMain.add(sp);
		pnlMain.add(pnlBottom,"South");

		File file = new File("Manager.txt");
		int i = 0;	
		try {
				inputStream = new BufferedReader(new FileReader(file.toString()));
				l = ""; 
				String[] str = new String[100];
				while((l = inputStream.readLine()) != null){
					str[i] = l;
					i++;
				}
				String[] spl = new String[4];
				
				for(int j = 0 ; j < i; j++){
					spl = str[j].split("/");
			
					model.addRow(spl);
					model.fireTableDataChanged();
				}
				
			} catch (IOException e1) {
				// TODO 자동 생성된 catch 블록
				e1.printStackTrace();
			}
		
	
		this.add(pnlMain,"Center");
	}

	void setData(String[] data){
		model.addRow(data);
	}

	void defultData(){
		txtName.setText("");
		txtNo.setText("");
		txtPw.setText("");
		txtMemo.setText("");
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO 자동 생성된 메소드 스텁
		if(btnAddManager == e.getSource()){
	
				String[] str = new String[4];
				if(txtName.getText().equals("") || txtNo.getText().equals("") || txtPw.getText().equals("") || txtMemo.getText().equals("")){
					JOptionPane.showMessageDialog(table, "全ての空欄を詰めてください", "!", JOptionPane.OK_OPTION  );

				}else {
					int Check = 0;
					
					for(int i = 0 ; i < table.getRowCount(); i++){
						if(table.getValueAt(i, 1).equals(txtNo.getText())){
							JOptionPane.showMessageDialog(table, "IDを確認してください", "!", JOptionPane.OK_OPTION  );
							txtNo.setText("");
							Check = 1;
							break;
						}
					}
					if(Check == 0){
						str[0] = txtName.getText();
						str[1] = txtNo.getText();
						str[2] = txtPw.getText();
						str[3] = txtMemo.getText();
					
						setData(str);
						defultData();
					}
				}
		}else if(btnDeleteManager == e.getSource()){
			int selectRow  = table.getSelectedRow();
			if (selectRow == -1){
				JOptionPane.showMessageDialog(table, "選択してください", "!", JOptionPane.OK_OPTION  );

				return;
			}else{
				model.removeRow(selectRow);
			}
		}else if(btnCommit == e.getSource()){
			File file = new File("Manager.txt");
			FileWriter fileWriter;
			try {
				fileWriter = new FileWriter(file);
			    PrintWriter printWriter = new PrintWriter(fileWriter);
			    
				int row = table.getRowCount();
				int column = table.getColumnCount();
				for (int j = 0; j  < row; j++) {
				       for (int i = 0; i  < column; i++) {
				    	   printWriter.print(table.getValueAt(j, i)+"/");
				           
				       }
				       printWriter.println();
				}
			    printWriter.close();

			} catch (IOException e1) {
				// TODO 자동 생성된 catch 블록
				e1.printStackTrace();
			}
			

		}
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO 자동 생성된 메소드 스텁
		int row = table.getSelectedRow();
		txtName.setText(table.getValueAt(row, 0).toString());
		txtNo.setText(table.getValueAt(row, 1).toString());
		txtPw.setText(table.getValueAt(row, 2).toString());
		txtMemo.setText(table.getValueAt(row, 3).toString());

		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO 자동 생성된 메소드 스텁
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO 자동 생성된 메소드 스텁
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO 자동 생성된 메소드 스텁
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO 자동 생성된 메소드 스텁
	}
}