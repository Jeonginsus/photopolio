package sell;


import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

class ErrorLackStock extends JDialog implements ActionListener {// 재고부족시 호출
	JButton btnClose;

	public ErrorLackStock() {
		setSize(150, 100);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		JLabel label = new JLabel("残り在庫がありません");
		label.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		JPanel panel = new JPanel();
		btnClose = new JButton("閉める");
		btnClose.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnClose.addActionListener(this);
		panel.add(label);
		panel.add(btnClose);
		this.add(panel);

		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		dispose();
	}

}

class ErrorLackMoney extends JDialog implements ActionListener {// 금액부족시 호출
	JButton btnClose;

	public ErrorLackMoney() {
		setSize(150, 100);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		JLabel label = new JLabel("金額を教えてください");
		label.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		JPanel panel = new JPanel();
		btnClose = new JButton("閉める");
		btnClose.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnClose.addActionListener(this);
		panel.add(label);
		panel.add(btnClose);
		this.add(panel);

		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		dispose();
	}

}

public class SellingControl extends JPanel implements ActionListener, MouseListener {// 메인
																				// 패널
	private JButton btnSell, btnAddBook, btnDelRow, btnDelOne, btnSearch;
	private JTable tableSearch, tableSell;
	private JTextField tfTotal, tfReceived, tfChange, tfSearch;
	private String[] header = { "タイトル", "著者", "値段", "ジャンル", "図書管理ナンバー", "数" };
	private String[][] contents = {};
	private DefaultTableModel modelSearch, modelSell;
	private int sellRow, searchRow, numTotal, numReceived, total, count;
	private String[] addGroup;
	private String keyWord;
	private BufferedReader inputStream;
	private PrintWriter outPutStream;
	private String l;
	private int k = 1;
	private PrintWriter outPutStream2;
	private BufferedReader inputStream2;

	public SellingControl() {
		this.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
		setLayout(new BorderLayout());
		JPanel pnlMain = new JPanel(new BorderLayout());
		JPanel pnlSub1 = new JPanel(new GridLayout(1, 2, 20, 20));
		JPanel pnlSub2 = new JPanel(new BorderLayout());
		JPanel pnlSearch = new JPanel(new BorderLayout());
		JPanel pnlScPnl = new JPanel(new GridLayout(2, 0, 10, 10));
		JPanel pnlSearchForRight = new JPanel();
		pnlSub1.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));
		JPanel pnlBtn = new JPanel(new GridLayout(2, 2, 10, 10));
		JPanel pnlCalculation = new JPanel(new GridLayout(3, 2, 10, 10));

		total = 0;

		tfSearch = new JTextField(20);
		btnSearch = new JButton("探す");
		btnSearch.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnSearch.addActionListener(this);
		pnlSearchForRight.add(btnSearch);
		pnlSearchForRight.add(tfSearch);
		pnlSearch.add(pnlSearchForRight, "East");
		pnlMain.add(pnlSearch, "North");

		modelSearch = new DefaultTableModel(contents, header) {

			public boolean isCellEditable(int i, int c) {
				return false;
			}
		};
		tableSearch = new JTable(modelSearch);
		tableSearch.addMouseListener(this);
		JScrollPane pnlScSearch = new JScrollPane(tableSearch);

		modelSell = new DefaultTableModel(contents, header) {

			public boolean isCellEditable(int i, int c) {
				return false;
			}

		};
		tableSell = new JTable(modelSell);
		tableSell.addMouseListener(this);
		JScrollPane pnlScSell = new JScrollPane(tableSell);

		pnlScPnl.add(pnlScSearch);
		pnlScPnl.add(pnlScSell);

		btnAddBook = new JButton("追加する");
		btnAddBook.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnAddBook.addActionListener(this);
		btnSell = new JButton("販売");
		btnSell.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnSell.addActionListener(this);
		btnDelRow = new JButton("品出し");
		btnDelRow.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnDelRow.addActionListener(this);
		btnDelOne = new JButton("一個出す");
		btnDelOne.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnDelOne.addActionListener(this);

		pnlBtn.add(btnAddBook);
		pnlBtn.add(btnDelRow);
		pnlBtn.add(btnDelOne);
		pnlBtn.add(btnSell);

		JLabel lblTotal = new JLabel("合計");
		lblTotal.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		JLabel lblReceived = new JLabel("値段");
		lblReceived.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		JLabel lblChange = new JLabel("残り");
		lblChange.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		tfTotal = new JTextField();
		tfReceived = new JTextField();
		tfChange = new JTextField();

		pnlCalculation.add(lblTotal);
		pnlCalculation.add(tfTotal);
		pnlCalculation.add(lblReceived);
		pnlCalculation.add(tfReceived);
		pnlCalculation.add(lblChange);
		pnlCalculation.add(tfChange);

		pnlSub1.add(pnlBtn);
		pnlSub1.add(pnlCalculation);
		pnlSub2.add(pnlScPnl, "Center");
		pnlSub2.add(pnlSub1, "South");
		pnlMain.add(pnlSub2, "Center");
		this.add(pnlMain, "Center");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnAddBook) {// search 테이블에서 구매 테이블로 이동
			tfChange.setText("");// 이전 잔돈 초기화
			tfReceived.setText("");// 이전 받은 돈 초기화
			count++;
			// 옯겨줄 변수 값 생성 및추가
			addGroup = new String[6];
			for (int i = 0; i < 5; i++) {
				addGroup[i] = String.valueOf(modelSearch.getValueAt(searchRow, i));
			}
			addGroup[5] = "1";
			modelSell.addRow(addGroup);
			// 재고 부족시 오류 창 호출 및 수정
			if (count == 1 && Integer.valueOf((String) modelSearch.getValueAt(searchRow, 5)) < 1) {
				JOptionPane.showMessageDialog(this, "残りを確認してください");
				modelSell.removeRow(modelSell.getRowCount() - 1);
				count = 0;

				total -= Integer.parseInt(addGroup[2]);
				// 추가후 이름 확인후 수량 추가
			} else {
				for (int i = 0; i < modelSell.getRowCount() - 1; i++) {
					if (modelSell.getRowCount() != 1
							&& modelSell.getValueAt(modelSell.getRowCount() - 1, 0) == modelSell.getValueAt(i, 0)) {
						modelSell.removeRow(modelSell.getRowCount() - 1);
						if (Integer.valueOf((String) modelSell.getValueAt(i, 5)) < Integer
								.valueOf((String) modelSearch.getValueAt(searchRow, 5))) {
							modelSell.setValueAt(
									String.valueOf(Integer.valueOf((String) modelSell.getValueAt(i, 5)) + 1), i, 5);

							break;
							// 재고 확인후 수량만 추가
						} else {
							JOptionPane.showMessageDialog(this, "残りを確認してください");
							total -= Integer.parseInt(addGroup[2]);
							count--;
							break;
						}
					}
				}
			}
			total += Integer.parseInt(addGroup[2]);// 총금액 합산
			tfTotal.setText(String.valueOf(total));

		} else if (e.getSource() == btnSell) {
			Calendar cal = Calendar.getInstance();
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH) + 1;
			int date = cal.get(Calendar.DATE);

			numTotal = Integer.parseInt(tfTotal.getText());// 총금액 가져오기
			numReceived = Integer.parseInt(tfReceived.getText());// 메인창에서 입력된
																	// 받은돈 값가져오기
			if (tfReceived.getText() != null && numTotal <= numReceived) {

				tfChange.setText(Integer.toString(numReceived - numTotal));// 잔돈
				JOptionPane.showMessageDialog(this, "판매되었습니다. 거스름돈은 "+Integer.toString(numReceived - numTotal)+"원입니다.");// 표기
				// 이전 매출 현황 파일 읽어오기
				try {
					outPutStream = new PrintWriter(new FileWriter("SalesStatus.txt", true));
					outPutStream.println();
				} catch (IOException e1) {
					// TODO 자동 생성된 catch 블록
					e1.printStackTrace();
				}
				// 새로운 매출 사항 불러오기 및 입력
				for (int i = 0; i < modelSell.getRowCount(); i++) {
					for (int j = 0; j < 6; j++) {
						outPutStream.print(modelSell.getValueAt(i, j) + "/");
					}
					if (k < Integer.valueOf((String) modelSell.getValueAt(i, 5))) {
						i--;
						k++;
					}
					// 시간추가
					outPutStream.print(year + "/");
					outPutStream.print(month + "/");
					if (i != modelSell.getRowCount() - 1) {
						outPutStream.println(date);
					} else {
						outPutStream.print(date);
					}
				}
				// booklist 불러오기 입력
				try {
					inputStream2 = new BufferedReader(new FileReader("BookList.txt"));
				} catch (FileNotFoundException e1) {
					// TODO 자동 생성된 catch 블록
					e1.printStackTrace();
				}
				String[][] addStringinString = new String[10000][6];
				String strInput = "";
				int inputCount = 0;
				try {
					while ((strInput = inputStream2.readLine()) != null) {
						addStringinString[inputCount] = strInput.split("/");
						inputCount++;
					}
				} catch (IOException e1) {
					// TODO 자동 생성된 catch 블록
					e1.printStackTrace();
				}
				// booklist 팔린 책수량 조정
				for (int i = 0; i < inputCount; i++) {
					for (int j = 0; j < modelSell.getRowCount(); j++) {
						if (addStringinString[i][0].equals(modelSell.getValueAt(j, 0))) {
							addStringinString[i][5] = String.valueOf(Integer.parseInt(addStringinString[i][5]) - 1);
							if (modelSell.getValueAt(j, 5).equals("1") == false) {
								i--;
								modelSell.setValueAt(
										String.valueOf(Integer.valueOf((String) modelSell.getValueAt(j, 5)) - 1), j, 5);
							}
						}
					}
				}
				// 수정된 booklist 넣기
				try {
					outPutStream2 = new PrintWriter(new FileWriter("BookList.txt"));
				} catch (IOException e1) {
					// TODO 자동 생성된 catch 블록
					e1.printStackTrace();
				}
				for (int i = 0; i < addStringinString.length; i++) {
					for (int j = 0; j < 6; j++) {
						if (addStringinString[i][j] != null) {
							outPutStream2.print(addStringinString[i][j]);
						} else {
							break;
						}
						if (j != 5) {
							outPutStream2.print("/");
						} else {
							outPutStream2.println("");
						}
					}
				}
				if (outPutStream2 != null) {
					outPutStream2.close();
				}
				if (inputStream2 != null) {
					try {
						inputStream2.close();
					} catch (IOException e1) {
						// TODO 자동 생성된 catch 블록
						e1.printStackTrace();
					}
				}
				tfTotal.setText("");
				tfReceived.setText("");
				total = 0;
				modelSearch.setRowCount(0);
				modelSell.setNumRows(0);
			} else {// 금액 오류시 호출
				JOptionPane.showMessageDialog(this, "금액이 부족합니다.");
			}
			
			if (outPutStream != null) {
				outPutStream.close();
			}
			// 삭제 버튼
		} else if (e.getSource() == btnDelRow) {
			total -= Integer.valueOf((String) modelSell.getValueAt(sellRow, 2))
					* Integer.valueOf((String) modelSell.getValueAt(sellRow, 5));
			tfTotal.setText(String.valueOf(total));
			modelSell.removeRow(sellRow);// sell테이블에서 선택한 열 삭제
			// 위쪽 검색 버튼
		} else if (e.getSource() == btnSearch) {
			modelSearch.setNumRows(0);
			keyWord = tfSearch.getText();
			tfSearch.setText("");
			File file = new File("BookList.txt");
			int i = 0;
			try {
				inputStream = new BufferedReader(new FileReader(file.toString()));
				l = "";
				String[] str = new String[1000];

				while ((l = inputStream.readLine()) != null) {
					str[i] = l;
					i++;
				}
				String[] spl = new String[6];

				for (int j = 0; j < i; j++) {
					spl = str[j].split("/");
					if (spl[0].indexOf(keyWord) != -1) {// 특정 단어가 있을시 search
														// 테이블에 추가 그냥 버튼 누를시
														// booklist 전체 출력
						modelSearch.addRow(spl);
					}
				}
				repaint();
			} catch (IOException e1) {
				// TODO 자동 생성된 catch 블록
				e1.printStackTrace();
			}
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e1) {
					// TODO 자동 생성된 catch 블록
					e1.printStackTrace();
				}
			}
			// 한줄 삭제
		} else if (e.getSource() == btnDelOne) {
			if (Integer.valueOf((String) modelSell.getValueAt(sellRow, 5)) > 0) {
				total -= Integer.valueOf((String) modelSell.getValueAt(sellRow, 2));
				tfTotal.setText(String.valueOf(total));
				modelSell.setValueAt(String.valueOf(Integer.valueOf((String) modelSell.getValueAt(sellRow, 5)) - 1),
						sellRow, 5);
			}
			if (Integer.valueOf((String) modelSell.getValueAt(sellRow, 5)) == 0) {
				modelSell.removeRow(sellRow);
			}
		}

	}

	// 선택된 열을 getSelectedRow()로 가져옴
	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == tableSell) {
			sellRow = tableSell.getSelectedRow();
		} else if (e.getSource() == tableSearch) {
			searchRow = tableSearch.getSelectedRow();
			count = 0;
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}
}
