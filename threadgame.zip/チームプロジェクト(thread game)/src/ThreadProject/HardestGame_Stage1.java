package ThreadProject;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class HardestGame_Stage1 extends JDialog implements KeyListener, Runnable {
	JButton btPlayer, btTarget;
	MainPage mp;
	// �÷��̾� ���� ��ġ
	int xPlayer = 110;
	int yPlayer = 600;
	// Ÿ�� ��ġ
	int xTarget = 10;
	int yTarget = 10;
	// Ÿ���� ��� ������ Ŭ����
	int count;
	int dCount;
	// Runnable ����ؼ� ������ ����
	Thread th;
	// Ű�����ʿ��� �� �޼���
	// true�� �������� �־��ֱ�-Keyprocess
	boolean KeyUp = false;
	boolean KeyDown = false;
	boolean KeyLeft = false;
	boolean KeyRight = false;
	boolean isEnd = true;
	JLabel lbl;
	
	Music backgroundMusic = new Music("InGame.wav", 36000, true);


	Timer t;

	public HardestGame_Stage1(MainPage mp) {
		this.mp = mp;
		setTitle("����� �����_Stage1");
		setSize(300, 700);
		setLayout(null);
		init();

		// âũ�⺯��Ұ�
		setResizable(false);
		setVisible(true);
		// �������� ȭ�� �߾ӿ� ��ġ�ϰ�
		setLocationRelativeTo(null);
		add(btPlayer);
		// �ߺ����� �Դ� �� ����
		btTarget.setText("Alive");
		add(btTarget);
		lbl = new JLabel();
		lbl.setBounds(70, 10, 500, 20);
		lbl.setText("��ī �ݶ�" + dCount + "�� ����");
		lbl.setForeground(Color.white);

		this.add(lbl);
	}

	void init() {
		backgroundMusic.start();
		setContentPane(new JLabel(new ImageIcon("PepsiLong.png")));
		btPlayer = new JButton(new ImageIcon("PlayerPepsi.png"));
		btTarget = new JButton(new ImageIcon("TargetHumanDrink.png"));

		btPlayer.setBorderPainted(false);
		btPlayer.setContentAreaFilled(false);
		btPlayer.setFocusable(false);
		btPlayer.setOpaque(false);
		btTarget.setBorderPainted(false);
		btTarget.setContentAreaFilled(false);
		btTarget.setFocusable(false);
		btTarget.setOpaque(false);
		btTarget.setBounds(xTarget, yTarget, 30, 30);
		// �� ���� �κ�
		EneThread_stage1 strene1 = new EneThread_stage1(this, 0, 50, 25, 25, Color.GREEN, 30);
		strene1.start();
		EneThread_stage1 strene2 = new EneThread_stage1(this, 275, 100, 25, 25, Color.GREEN, 30);
		strene2.start();
		EneThread_stage1 strene3 = new EneThread_stage1(this, 0, 150, 25, 25, Color.GREEN, 30);
		strene3.start();
		EneThread_stage1 strene4 = new EneThread_stage1(this, 275, 200, 25, 25, Color.GREEN, 30);
		strene4.start();
		EneThread_stage1 strene5 = new EneThread_stage1(this, 0, 250, 25, 25, Color.GREEN, 30);
		strene5.start();
		EneThread_stage1 strene6 = new EneThread_stage1(this, 275, 300, 25, 25, Color.GREEN, 30);
		strene6.start();
		EneThread_stage1 strene7 = new EneThread_stage1(this, 0, 350, 25, 25, Color.GREEN, 30);
		strene7.start();
		EneThread_stage1 strene8 = new EneThread_stage1(this, 275, 400, 25, 25, Color.GREEN, 30);
		strene8.start();
		EneThread_stage1 strene9 = new EneThread_stage1(this, 0, 450, 25, 25, Color.GREEN, 30);
		strene9.start();
		EneThread_stage1 strene10 = new EneThread_stage1(this, 275, 500, 25, 25, Color.GREEN, 30);
		strene10.start();
		EneThread_stage1 strene11 = new EneThread_stage1(this, 0, 550, 25, 25, Color.GREEN, 30);
		strene11.start();
		// �� ���� ��

		th = new Thread(this);
		th.start();

		this.addKeyListener(this);
		this.setFocusable(true);
	}

	public void GetTarget() {

		// Ÿ�� �ߺ� ȹ�� ����
		if (btTarget.getText() == "Alive") {

			// �浹����
			if (((xPlayer <= xTarget && xPlayer + 19 > xTarget) || (xTarget <= xPlayer && xTarget + 28 > xPlayer))
					&& ((yPlayer <= yTarget && yPlayer + 19 > yTarget)
							|| (yTarget <= yPlayer && yTarget + 28 > yPlayer))) {
				// "Alive"�϶��� �浹�����̹Ƿ� "Get"���� �ٲ㼭 ������ �������� ���ϰ� ����
				btTarget.setText("Get!");
				remove(btTarget);

				count += 1;

				if (count == 1) {
					// ������ �ݱ�

					isEnd = false;
					new Music("drink.wav", 12000).start();
					JOptionPane.showMessageDialog(this, "��! ��ô�!", "Ŭ����!", 3, new ImageIcon("Relax.jpg", "North"));
					backgroundMusic.remove();
					dispose();

					new HardestGame_Stage2(mp);
				}
				mp.btStage2.setEnabled(true);
				repaint();
				revalidate();
			}

		}
	}

	public void KeyProcess() {
		// ������ ĳ���� ������ ������ ����
		// ������ �޾Ƶ��� Ű���� ��������
		// Ű �Է½ø��� 5��ŭ�� �̵��� ��Ų��.

		if (KeyUp == true)
			// ȭ�� ������ �ȳ������� ���� ����
			if (yPlayer >= 0) {
				yPlayer -= 3;
			}
		if (KeyDown == true)
			if (yPlayer <= 640) {
				yPlayer += 3;
			}
		if (KeyLeft == true)
			if (xPlayer >= 0) {
				xPlayer -= 3;
			}
		if (KeyRight == true)
			if (xPlayer <= 165) {
				xPlayer += 3;
			}
		btPlayer.setBounds(xPlayer, yPlayer, 20, 20);

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = true;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = true;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = true;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = true;
			break;
		}
		if(e.getKeyCode()==KeyEvent.VK_SPACE){
			backgroundMusic.remove();
	         dispose();
	      }
		GetTarget();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = false;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = false;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = false;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = false;
			break;
		}
		GetTarget();
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (isEnd) {
			KeyProcess();
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

// ���η� �����̴� �� ������
class EneThread_stage1 extends Thread {
	// ���� ������ ���ؼ�
	boolean isLeft = true;
	boolean isUp = true;
	// ��� ������ �� �ֵ���
	boolean isRunning = true;
	// ��ǥ����
	int etx, ety, etw, eth, etxMove, etyMove;

	HardestGame_Stage1 frame;
	JButton eneBtn;
	int speed;

	public EneThread_stage1(HardestGame_Stage1 frame, int x, int y, int w, int h, Color c, int speed) {
		this.frame = frame;
		this.etx = x;
		this.ety = y;
		this.etw = w;
		this.eth = h;
		this.speed = speed;
		eneBtn = new JButton(new ImageIcon("EnemyCoca.png"));
		eneBtn.setBorderPainted(false);
		eneBtn.setContentAreaFilled(false);
		eneBtn.setFocusable(false);
		eneBtn.setOpaque(false);
		eneBtn.setBackground(c);
		eneBtn.setBounds(x, y, etw, eth);
		frame.add(eneBtn);
	}

	@Override
	public void run() {
		while (isRunning) {
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (isLeft) {
				etx += 10;
				if (etx > 300) {
					isLeft = false;
				}
			} else {// isLeft�� false �϶� ����
				etx -= 10;
				if (etx < -50) {
					isLeft = true;
				}
			}
			eneBtn.setLocation(etx, ety);
			// �浹����
			if (((frame.xPlayer < etx && frame.xPlayer + 19 > etx)
					|| (etx <= frame.xPlayer && etx + (etw - 1) > frame.xPlayer))
					&& ((frame.yPlayer <= ety && frame.yPlayer + 19 > ety)
							|| (ety <= frame.yPlayer && ety + (eth - 1) > frame.yPlayer))) {
				frame.dCount++;
				frame.lbl.setText("��ī �ݶ�" + frame.dCount + "�� ����");
				// �ٽ� �¾ ��ǥ
				frame.xPlayer = 110;
				frame.yPlayer = 600;
				frame.btPlayer.setBounds(frame.xPlayer, frame.yPlayer, 20, 20);
				new Music("CanCrush.wav", 1500).start();

			}
		} // while ��

	}
}