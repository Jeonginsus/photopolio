package ThreadProject;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.net.MalformedURLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Intro extends JPanel implements Runnable, KeyListener {

	Thread tr;
	
	Music backgroundMusic = new Music("Star Wars.wav", 127000, true);
	
	JLabel storyLbl1, storyLbl2;
	JLabel gifLbl, gifLbl2;
	JLabel backLbl;

	int x = 100;
	int y = 400;

	int gifX = 0;
	int gifY = 700;

	int x2 = 200;
	int y2 = 1300;

	int gifX2 = 0;
	int gifY2 = 1400;
	
	JFrame f;

	public Intro() throws MalformedURLException {
		backgroundMusic.start();
		storyLbl1 = new JLabel();
		String story1 = "<html><div style='text-align: center'>���� 2020��, ����ݶ� �̹ڰ� ���ظ� �޾ƿ��� ��� 55��...<br/><br/>�׵��� ������ ���� ������ ���ƿԴ�...</div></html>";
		storyLbl1.setText(story1);
		storyLbl1.setBounds(x, y, 580, 300);
		storyLbl1.setFont(new Font("���� ����", Font.BOLD, 20));
		this.add(storyLbl1);

		gifLbl = new JLabel(makeImage("throwpepsi.gif"));
		gifLbl.setBounds(gifX, gifY, 750, 100);
		this.add(gifLbl);

		storyLbl2 = new JLabel();
		String story2 = "<html><div style='text-align: center'>�츱 �Һ����� �ʴ´ٸ�...<br/><br/> �츮�� �װյ��� �Կ� ������ ã�ư� ���̴�.<br/><br/>�������̿� �Ͼ��!</div></html>";
		storyLbl2.setText(story2);
		storyLbl2.setBounds(x2, y2, 580, 300);
		storyLbl2.setFont(new Font("���� ����", Font.BOLD, 20));
		this.add(storyLbl2);

		gifLbl2 = new JLabel(makeImage("pepsiman.jpg"));
		gifLbl2.setBounds(gifX2, gifY2, 800, 100);
		this.add(gifLbl2);

		backLbl = new JLabel(makeImage("mainBack.png"));
		backLbl.setBounds(0, 0, 800, 580);
		this.add(backLbl);

		tr = new Thread(this);
		tr.start();

		this.setLayout(null);

		f = new JFrame();
		f.addKeyListener(this);
	    f.setFocusable(true);
		f.add(this);
		f.setSize(800, 580);
		f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
	}

	public ImageIcon makeImage(String name) {
		Image image = Toolkit.getDefaultToolkit().createImage(name);
		return new ImageIcon(image);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = y; i >= -900; i--) {
			y -= 1;
			gifY -= 1;
			y2 -= 1;
			gifY2 -= 1;
			try {
				tr.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			storyLbl1.setBounds(x, y, 580, 300);
			gifLbl.setBounds(gifX, gifY, 750, 500);
			storyLbl2.setBounds(x2, y2, 580, 300);
			gifLbl2.setBounds(gifX2, gifY2, 800, 500);
		}
	}

	public static void main(String[] args) {
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode()==KeyEvent.VK_SPACE){
	         backgroundMusic.remove();
	         f.dispose();
	      }
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}