package ThreadProject;

import java.io.File;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;

public class Music extends Thread {
	String name;
	int time;
	boolean again = false;
	Clip clip;

	public Music(String name, int time) {//�ѹ� ����û��
		this.name = name;
		this.time = time;
	}

	public Music(String name, int time, boolean again) {//�ݺ����ǽû��
		this.name = name;
		this.time = time;
		this.again = again;
	}

	public void run() {
		File bgm;
		AudioInputStream stream;
		AudioFormat format;
		DataLine.Info info;

		bgm = new File(name); // ���ÿ��� ���� ������ ������ ��
		if (again) {//�ݺ�����
			while (again) {
				try {
					stream = AudioSystem.getAudioInputStream(bgm);
					format = stream.getFormat();
					info = new DataLine.Info(Clip.class, format);
					clip = (Clip) AudioSystem.getLine(info);
					clip.open(stream);
					clip.start();

				} catch (Exception e) {
					System.out.println("err : " + e);
				}
				try {
					Thread.sleep(time);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else {//�ѹ����
			try {
				stream = AudioSystem.getAudioInputStream(bgm);
				format = stream.getFormat();
				info = new DataLine.Info(Clip.class, format);
				clip = (Clip) AudioSystem.getLine(info);
				clip.open(stream);
				clip.start();

			} catch (Exception e) {
				System.out.println("err : " + e);
			}
			try {
				Thread.sleep(time);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public void remove() {//��������
		clip.stop();
		again = false;
	}

}