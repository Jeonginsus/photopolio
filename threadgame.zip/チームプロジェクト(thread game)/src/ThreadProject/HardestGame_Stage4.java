package ThreadProject;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class HardestGame_Stage4 extends JFrame implements KeyListener, Runnable {
	JButton btPlayer, btTarget;
	int xPlayer = 210;
	int yPlayer = 420;
	int xTarget = 50;
	int yTarget = 10;
	int count;
	JLabel lbl;
	int dCount;
	MainPage mp;
	Thread th;
	boolean KeyUp = false;
	boolean KeyDown = false;
	boolean KeyLeft = false;
	boolean KeyRight = false;
	boolean isEnd = true;

	Music backgroundMusic = new Music("InGame.wav", 36000, true);

	public HardestGame_Stage4(MainPage mp) {
		this.mp = mp;
		setTitle("����� �����_Stage4");
		setSize(500, 500);
		setLayout(null);
		init();
		setResizable(false);
		setVisible(true);
		setLocationRelativeTo(null);
		add(btPlayer);
		btTarget.setText("Alive");
		add(btTarget);
	}

	void init() {
		backgroundMusic.start();
		setContentPane(new JLabel(new ImageIcon("Pepsi.jpg")));
		btPlayer = new JButton(new ImageIcon("PlayerPepsi.png"));
		btPlayer.setBorderPainted(false);
		btPlayer.setContentAreaFilled(false);
		btPlayer.setFocusable(false);
		btPlayer.setOpaque(false);
		btTarget = new JButton(new ImageIcon("TargetHumanDrink.png"));
		btTarget.setBorderPainted(false);
		btTarget.setContentAreaFilled(false);
		btTarget.setFocusable(false);
		btTarget.setOpaque(false);
		btTarget.setBounds(xTarget, yTarget, 30, 30);
		// �� ���� �κ�
		EneThread_stage4 strene1 = new EneThread_stage4(this, 0, 50, 25, 25, Color.GREEN, 20);
		strene1.start();
		EneThread_stage4 strene2 = new EneThread_stage4(this, 450, 110, 25, 25, Color.GREEN, 20);
		strene2.start();
		EneThread_stage4 strene3 = new EneThread_stage4(this, 0, 170, 25, 25, Color.GREEN, 20);
		strene3.start();
		EneThread_stage4 strene4 = new EneThread_stage4(this, 450, 240, 25, 25, Color.GREEN, 20);
		strene4.start();
		EneThread_stage4 strene5 = new EneThread_stage4(this, 0, 300, 25, 25, Color.GREEN, 20);
		strene5.start();

		EneThread4_stage4 updownEne1 = new EneThread4_stage4(this, 20, 0, 20, 20, Color.BLACK, 20);
		updownEne1.start();
		EneThread4_stage4 updownEne2 = new EneThread4_stage4(this, 120, 480, 20, 20, Color.BLACK, 20);
		updownEne2.start();
		EneThread4_stage4 updownEne3 = new EneThread4_stage4(this, 180, 0, 20, 20, Color.BLACK, 20);
		updownEne3.start();
		EneThread4_stage4 updownEne4 = new EneThread4_stage4(this, 240, 480, 20, 20, Color.BLACK, 20);
		updownEne4.start();
		EneThread4_stage4 updownEne5 = new EneThread4_stage4(this, 300, 0, 20, 20, Color.BLACK, 20);
		updownEne5.start();
		// �� ���� ��
		lbl = new JLabel("��ī �ݶ�" + dCount + "�� ����");
		lbl.setBounds(250, 10, 500, 20);
		lbl.setText("��ī �ݶ�" + dCount + "�� ����");
		lbl.setForeground(Color.white);
		add(lbl);

		th = new Thread(this);
		th.start();

		this.addKeyListener(this);
		this.setFocusable(true);
	}

	public void GetTarget() {
		// Ÿ�� �ߺ� ȹ�� ����
		if (btTarget.getText() == "Alive") {

			// �浹����
			if (((xPlayer <= xTarget && xPlayer + 20 > xTarget) || (xTarget <= xPlayer && xTarget + 31 > xPlayer))
					&& ((yPlayer <= yTarget && yPlayer + 20 > yTarget)
							|| (yTarget <= yPlayer && yTarget + 31 > yPlayer))) {
				// "Alive"�϶��� �浹�����̹Ƿ� "Get"���� �ٲ㼭 ������ �������� ���ϰ� ����
				btTarget.setText("Get!");
				remove(btTarget);
				count += 1;
				if (count == 1) {
					// ������ �ݱ�
					isEnd = false;
					new Music("drink.wav", 12000).start();
					JOptionPane.showMessageDialog(this, "��! ��ô�!", "Ŭ����!", 3, new ImageIcon("Relax.jpg", "North"));
					backgroundMusic.remove();
					dispose();
					new HardestGame_Stage5(mp);
				}
				mp.btStage5.setEnabled(true);
				repaint();
				revalidate();
			}

		}
	}

	public void KeyProcess() {
		// ������ ĳ���� ������ ������ ����
		// ������ �޾Ƶ��� Ű���� ��������
		// Ű �Է½ø��� 5��ŭ�� �̵��� ��Ų��.

		if (KeyUp == true)
			if (yPlayer >= 5) {
				yPlayer -= 5;
			}
		if (KeyDown == true)
			if (yPlayer <= 435) {
				yPlayer += 5;
			}
		if (KeyLeft == true)
			if (xPlayer >= 5) {
				xPlayer -= 5;
			}
		if (KeyRight == true)
			if (xPlayer <= 460) {
				xPlayer += 5;
			}
		btPlayer.setBounds(xPlayer, yPlayer, 20, 20);

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = true;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = true;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = true;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = true;
			break;
		}
		if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			backgroundMusic.remove();
			dispose();
		}
		GetTarget();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = false;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = false;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = false;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = false;
			break;
		}
		GetTarget();
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (isEnd) {
			KeyProcess();
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

class EneThread_stage4 extends Thread {
	boolean isLeft = true;
	boolean isUp = true;
	boolean isRunning = true;
	int etx, ety, etw, eth, etxMove, etyMove;

	HardestGame_Stage4 frame;
	JButton eneBtn;
	int speed;

	public EneThread_stage4(HardestGame_Stage4 frame, int x, int y, int w, int h, Color c, int speed) {
		this.frame = frame;
		this.etx = x;
		this.ety = y;
		this.etw = w;
		this.eth = h;
		this.speed = speed;
		eneBtn = new JButton(new ImageIcon("EnemyCoca.png"));
		eneBtn.setBorderPainted(false);
		eneBtn.setContentAreaFilled(false);
		eneBtn.setFocusable(false);
		eneBtn.setOpaque(false);
		eneBtn.setBackground(c);
		eneBtn.setBounds(x, y, etw, eth);
		frame.add(eneBtn);
	}

	@Override
	public void run() {
		while (isRunning) {
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (isLeft) {
				etx += 10;
				if (etx > 450) {
					isLeft = false;
				}
			} else {// isLeft�� false �϶� ����
				etx -= 10;
				if (etx < 0) {
					isLeft = true;
				}
			}
			eneBtn.setLocation(etx, ety);
			// �浹����
			if (((frame.xPlayer < etx && frame.xPlayer + 19 > etx)
					|| (etx <= frame.xPlayer && etx + (etw - 1) > frame.xPlayer))
					&& ((frame.yPlayer <= ety && frame.yPlayer + 19 > ety)
							|| (ety <= frame.yPlayer && ety + (eth - 1) > frame.yPlayer))) {
				frame.dCount++;
				frame.lbl.setText("��ī �ݶ�" + frame.dCount + "�� ����");
				frame.xPlayer = 210;
				frame.yPlayer = 420;
				frame.btPlayer.setBounds(frame.xPlayer, frame.yPlayer, 20, 20);
				new Music("CanCrush.wav", 1500).start();

			}
		} // while ��

	}
}

class EneThread4_stage4 extends Thread {
	boolean isLeft = true;
	boolean isUp = true;
	boolean isRunning = true;
	int etx, ety, etw, eth, etxMove, etyMove;

	HardestGame_Stage4 frame;
	JButton eneBtn;
	int speed;

	public EneThread4_stage4(HardestGame_Stage4 frame, int x, int y, int w, int h, Color c, int speed) {
		this.frame = frame;
		this.etx = x;
		this.ety = y;
		this.etw = w;
		this.eth = h;
		this.speed = speed;
		eneBtn = new JButton(new ImageIcon("EnemyCoca.png"));
		eneBtn.setBackground(c);
		eneBtn.setBounds(x, y, etw, eth);
		frame.add(eneBtn);
	}

	@Override
	public void run() {
		while (isRunning) {
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (isUp) {
				ety += 10;
				if (ety > 450) {
					isUp = false;
				}
			} else {// isLeft�� false �϶� ����
				ety -= 10;
				if (ety < 0) {
					isUp = true;
				}
			}
			eneBtn.setLocation(etx, ety);
			if (((frame.xPlayer < etx && frame.xPlayer + 19 > etx)
					|| (etx <= frame.xPlayer && etx + (etw - 1) > frame.xPlayer))
					&& ((frame.yPlayer <= ety && frame.yPlayer + 19 > ety)
							|| (ety <= frame.yPlayer && ety + (eth - 1) > frame.yPlayer))) {
				frame.dCount++;
				frame.lbl.setText("��ī �ݶ�" + frame.dCount + "�� ����");
				frame.xPlayer = 210;
				frame.yPlayer = 420;
				frame.btPlayer.setBounds(frame.xPlayer, frame.yPlayer, 20, 20);
				new Music("CanCrush.wav", 1500).start();

			}
		} // while ��

	}
}