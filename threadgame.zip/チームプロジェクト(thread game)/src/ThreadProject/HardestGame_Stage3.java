package ThreadProject;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class HardestGame_Stage3 extends JFrame implements KeyListener, Runnable {
	JButton btPlayer, btTarget;
	MainPage mp;
	int xPlayer = 130;
	int yPlayer = 600;
	int xTarget = 100;
	int yTarget = 10;
	int count;
	JLabel lbl;
	int dCount;
	Thread th;
	boolean KeyUp = false;
	boolean KeyDown = false;
	boolean KeyLeft = false;
	boolean KeyRight = false;
	boolean isEnd = true;
	Music backgroundMusic = new Music("InGame.wav", 36000, true);

	public HardestGame_Stage3(MainPage mp) {
		this.mp = mp;
		setTitle("HardestGame_Stage3");
		setSize(300, 700);
		setLayout(null);
		init();
		setResizable(false);
		setVisible(true);
		setLocationRelativeTo(null);
		add(btPlayer);
		btTarget.setText("Alive");
		add(btTarget);
	}

	void init() {
		backgroundMusic.start();
		setContentPane(new JLabel(new ImageIcon("PepsiLong.png")));
		btPlayer = new JButton(new ImageIcon("PlayerPepsi.png"));
		btPlayer.setBorderPainted(false);
		btPlayer.setContentAreaFilled(false);
		btPlayer.setFocusable(false);
		btPlayer.setOpaque(false);
		btTarget = new JButton(new ImageIcon("TargetHumanDrink.png"));
		btTarget.setBorderPainted(false);
		btTarget.setContentAreaFilled(false);
		btTarget.setFocusable(false);
		btTarget.setOpaque(false);
		btTarget.setBounds(xTarget, yTarget, 30, 30);
		// �� ���� �κ�
		EneThread3_stage3 backracene1 = new EneThread3_stage3(this, 150, 150, 20, 20, 100, Color.BLACK, 5);
		backracene1.start();
		EneThread3_stage3 backracene2 = new EneThread3_stage3(this, 250, 150, 20, 20, 100, Color.BLACK, 5);
		backracene2.start();
		EneThread3_stage3 backracene3 = new EneThread3_stage3(this, 150, 250, 20, 20, 100, Color.BLACK, 5);
		backracene3.start();
		EneThread3_stage3 backracene4 = new EneThread3_stage3(this, 250, 250, 20, 20, 100, Color.BLACK, 5);
		backracene4.start();
		EneThread3_stage3 backracene5 = new EneThread3_stage3(this, 150, 350, 20, 20, 100, Color.BLACK, 5);
		backracene5.start();
		EneThread3_stage3 backracene6 = new EneThread3_stage3(this, 250, 350, 20, 20, 100, Color.BLACK, 5);
		backracene6.start();
		EneThread3_stage3 backracene7 = new EneThread3_stage3(this, 150, 450, 20, 20, 100, Color.BLACK, 5);
		backracene7.start();
		EneThread3_stage3 backracene8 = new EneThread3_stage3(this, 250, 450, 20, 20, 100, Color.BLACK, 5);
		backracene8.start();

		EneThread4_stage3 updownEne1 = new EneThread4_stage3(this, 0, 0, 20, 20, Color.BLACK, 20);
		updownEne1.start();
		EneThread4_stage3 updownEne2 = new EneThread4_stage3(this, 50, 650, 20, 20, Color.BLACK, 20);
		updownEne2.start();
		EneThread4_stage3 updownEne3 = new EneThread4_stage3(this, 100, 0, 20, 20, Color.BLACK, 20);
		updownEne3.start();
		EneThread4_stage3 updownEne4 = new EneThread4_stage3(this, 160, 650, 20, 20, Color.BLACK, 20);
		updownEne4.start();
		EneThread4_stage3 updownEne5 = new EneThread4_stage3(this, 210, 0, 20, 20, Color.BLACK, 20);
		updownEne5.start();
		EneThread4_stage3 updownEne6 = new EneThread4_stage3(this, 260, 650, 20, 20, Color.BLACK, 20);
		updownEne6.start();

		// �� ���� ��
		lbl = new JLabel("��ī �ݶ�" + dCount + "�� ����");
		lbl.setBounds(250, 10, 500, 20);
		lbl.setText("��ī �ݶ�" + dCount + "�� ����");
		add(lbl);
		lbl.setForeground(Color.white);
		th = new Thread(this);
		th.start();

		this.addKeyListener(this);
		this.setFocusable(true);
	}

	public void GetTarget() {
		// Ÿ�� �ߺ� ȹ�� ����
		if (btTarget.getText() == "Alive") {

			// �浹����
			if (((xPlayer <= xTarget && xPlayer + 20 > xTarget) || (xTarget <= xPlayer && xTarget + 31 > xPlayer))
					&& ((yPlayer <= yTarget && yPlayer + 20 > yTarget)
							|| (yTarget <= yPlayer && yTarget + 31 > yPlayer))) {
				// "Alive"�϶��� �浹�����̹Ƿ� "Get"���� �ٲ㼭 ������ �������� ���ϰ� ����
				btTarget.setText("Get!");
				remove(btTarget);
				count += 1;
				if (count == 1) {
					// ������ �ݱ�
					isEnd = false;
					new Music("drink.wav", 12000).start();
					JOptionPane.showMessageDialog(this, "��! ��ô�!", "Ŭ����!", 3, new ImageIcon("Relax.jpg", "North"));
					backgroundMusic.remove();
					dispose();
					new HardestGame_Stage4(mp);
				}
				mp.btStage4.setEnabled(true);
				repaint();
				revalidate();
			}

		}
	}

	public void KeyProcess() {
		// ������ ĳ���� ������ ������ ����
		// ������ �޾Ƶ��� Ű���� ��������
		// Ű �Է½ø��� 5��ŭ�� �̵��� ��Ų��.

		if (KeyUp == true)
			if (yPlayer >= 5) {
				yPlayer -= 5;
			}
		if (KeyDown == true)
			if (yPlayer <= 635) {
				yPlayer += 5;
			}
		if (KeyLeft == true)
			if (xPlayer >= 5) {
				xPlayer -= 5;
			}
		if (KeyRight == true)
			if (xPlayer <= 260) {
				xPlayer += 5;
			}
		btPlayer.setBounds(xPlayer, yPlayer, 20, 20);

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = true;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = true;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = true;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = true;
			break;
		}
		if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			backgroundMusic.remove();
			dispose();
		}
		GetTarget();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = false;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = false;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = false;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = false;
			break;
		}
		GetTarget();
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (isEnd) {
			KeyProcess();
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

class EneThread3_stage3 extends Thread {
	boolean isLeft = true;
	boolean isUp = true;
	boolean isRunning = true;
	int etx, ety, etw, eth, etxMove, etyMove, size;

	HardestGame_Stage3 frame;
	JButton eneBtn;
	int speed;

	public EneThread3_stage3(HardestGame_Stage3 frame, int x, int y, int w, int h, int size, Color c, int speed) {
		this.frame = frame;
		this.etx = x;
		this.ety = y;
		this.etw = w;
		this.eth = h;
		this.size = size;
		this.speed = speed;
		eneBtn = new JButton(new ImageIcon("EnemyCoca.png"));
		eneBtn.setBorderPainted(false);
		eneBtn.setContentAreaFilled(false);
		eneBtn.setFocusable(false);
		eneBtn.setOpaque(false);
		eneBtn.setBackground(c);
		eneBtn.setBounds(etx, ety, etw, eth);
		frame.add(eneBtn);
	}

	public void run() {
		// TODO Auto-generated method stub
		int x = etx;
		int y = ety;
		while (true) {
			// ó�� ��ǥ 2�� + �̵��� ��ġ ����ֱ�
			if (ety == y && etx <= x && etx > x - size) {
				etx -= 1;
			} else if (etx == x && ety < y && ety >= y - size) {
				ety += 1;
			} else if (ety == y - size && etx >= x - 100 && etx < x) {
				etx += 1;
			} else if (etx == x - size && ety <= y && ety > y - size) {
				ety -= 1;
			}

			eneBtn.setBounds(etx, ety, 20, 20);
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (((frame.xPlayer < etx && frame.xPlayer + 19 > etx)
					|| (etx <= frame.xPlayer && etx + (etw - 1) > frame.xPlayer))
					&& ((frame.yPlayer <= ety && frame.yPlayer + 19 > ety)
							|| (ety <= frame.yPlayer && ety + (eth - 1) > frame.yPlayer))) {
				frame.dCount++;
				frame.lbl.setText("��ī �ݶ�" + frame.dCount + "�� ����");
				frame.xPlayer = 130;
				frame.yPlayer = 600;
				frame.btPlayer.setBounds(frame.xPlayer, frame.yPlayer, 20, 20);
				new Music("CanCrush.wav", 1500).start();

			}
		}

	}
}

class EneThread4_stage3 extends Thread {
	boolean isLeft = true;
	boolean isUp = true;
	boolean isRunning = true;
	int etx, ety, etw, eth, etxMove, etyMove;

	HardestGame_Stage3 frame;
	JButton eneBtn;
	int speed;

	public EneThread4_stage3(HardestGame_Stage3 frame, int x, int y, int w, int h, Color c, int speed) {
		this.frame = frame;
		this.etx = x;
		this.ety = y;
		this.etw = w;
		this.eth = h;
		this.speed = speed;
		eneBtn = new JButton(new ImageIcon("EnemyCoca.png"));
		eneBtn.setBorderPainted(false);
		eneBtn.setContentAreaFilled(false);
		eneBtn.setFocusable(false);
		eneBtn.setOpaque(false);
		eneBtn.setBackground(c);
		eneBtn.setBounds(x, y, etw, eth);
		frame.add(eneBtn);
	}

	@Override
	public void run() {
		while (isRunning) {
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (isUp) {
				ety += 10;
				if (ety > 650) {
					isUp = false;
				}
			} else {// isLeft�� false �϶� ����
				ety -= 10;
				if (ety < 0) {
					isUp = true;
				}
			}
			eneBtn.setLocation(etx, ety);
			if (((frame.xPlayer < etx && frame.xPlayer + 19 > etx)
					|| (etx <= frame.xPlayer && etx + (etw - 1) > frame.xPlayer))
					&& ((frame.yPlayer <= ety && frame.yPlayer + 19 > ety)
							|| (ety <= frame.yPlayer && ety + (eth - 1) > frame.yPlayer))) {
				frame.dCount++;
				frame.lbl.setText("��ī �ݶ�" + frame.dCount + "�� ����");
				frame.xPlayer = 130;
				frame.yPlayer = 600;
				frame.btPlayer.setBounds(frame.xPlayer, frame.yPlayer, 20, 20);
				new Music("CanCrush.wav", 1500).start();

			}
		} // while ��

	}
}