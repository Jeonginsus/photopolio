package ThreadProject;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.net.MalformedURLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Tutorial extends JFrame implements KeyListener, Runnable {
	JButton btPlayer, btTarget;
	int xPlayer = 10;
	int yPlayer = 60;
	// Ÿ�� ��ġ
	int xTarget = 320;
	int yTarget = 60;
	Thread th;

	// Ű�����ʿ��� �� �޼��� // true�� �������� �־��ֱ�-Keyprocess //����Ŭ�� ������
	boolean KeyUp = false;
	boolean KeyDown = false;
	boolean KeyLeft = false;
	boolean KeyRight = false;

	Music backgroundMusic = new Music("InGame.wav", 36000, true);

	public Tutorial() {
		this.setSize(400, 200);
		setTitle("����� �����_Ʃ�丮��");
		this.setLayout(null);
		this.setResizable(false);
		setLocationRelativeTo(null);
		backgroundMusic.start();// �������� �����
		btPlayer = new JButton(new ImageIcon("PlayerPepsi.png"));
		btPlayer.setBounds(xPlayer, yPlayer, 20, 20);
		btPlayer.setBorderPainted(false);
		btPlayer.setContentAreaFilled(false);
		btPlayer.setFocusable(false);
		btPlayer.setOpaque(false);
		btTarget = new JButton(new ImageIcon("TargetHumanDrink.png"));
		btTarget.setBorderPainted(false);
		btTarget.setContentAreaFilled(false);
		btTarget.setFocusable(false);
		btTarget.setOpaque(false);
		btTarget.setBounds(xTarget, yTarget, 30, 30);
		btTarget.setText(" ");
		init();

		this.add(btPlayer);
		this.add(btTarget);
		this.addKeyListener(this);
		this.setFocusable(true);
		this.requestFocus();
		this.setVisible(true);

	}

	void init() {
		th = new Thread(this);
		th.start();
		EneThread1 et = new EneThread1(this, 80, 0, 10, 10, Color.RED, 50);
		et.start();
		EneThread1 et1 = new EneThread1(this, 180, 170, 10, 10, Color.RED, 50);
		et1.start();
		EneThread1 et2 = new EneThread1(this, 270, 0, 10, 10, Color.RED, 50);
		et2.start();
	}

	void crash() {
		if (btTarget.getText() == " ") {

			if (((xPlayer <= xTarget && xPlayer + 25 > xTarget) || (xTarget <= xPlayer && xTarget + 31 > xPlayer))
					&& ((yPlayer <= yTarget && yPlayer + 25 > yTarget)
							|| (yTarget <= yPlayer && yTarget + 31 > yPlayer))) {
				// ������ �κ�*************************************
				remove(btPlayer);
				btTarget.setText("��");
				new Music("drink.wav", 12000).start();
				JOptionPane.showMessageDialog(this, "��� ���� �Ѥ�");
				backgroundMusic.remove();
				dispose();
				try {
					Intro It = new Intro();
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// �������***************************************
			}

		}
		repaint();
		revalidate();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			KeyProcess();
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public void KeyProcess() { // Ű������. �� �޼��带 run�� �־� �ڿ������� �����̰�
		if (KeyUp == true)
			if (yPlayer >= 0) {
				yPlayer -= 3;
			}
		if (KeyDown == true)
			if (yPlayer <= 200) {
				yPlayer += 3;
			}
		if (KeyLeft == true)
			if (xPlayer >= 0) {
				xPlayer -= 3;
			}
		if (KeyRight == true)
			if (xPlayer <= 400) {
				xPlayer += 3;
			}
		btPlayer.setBounds(xPlayer, yPlayer, 30, 30);
		crash();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = true;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = true;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = true;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = true;
			break;
		}
		if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			backgroundMusic.remove();
			dispose();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = false;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = false;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = false;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = false;
			break;
		}

	}

	public static void main(String[] args) {
		new Tutorial();
	}

	public void keyTyped(KeyEvent arg0) {
	}

}

class EneThread1 extends Thread {
	JButton eneBtn;
	boolean isRunning = true;
	boolean isUp = true;
	Tutorial frame;
	int enx, eny, speed;
	int enh, enw;

	public EneThread1(Tutorial frame, int x, int y, int w, int h, Color c, int speed) {
		this.frame = frame;
		this.enx = x;
		this.eny = y;
		this.speed = speed;

		this.enw = w;
		this.enh = h;
		eneBtn = new JButton(new ImageIcon("EnemyCoca.png"));
		eneBtn.setBorderPainted(false);
		eneBtn.setContentAreaFilled(false);
		eneBtn.setFocusable(false);
		eneBtn.setOpaque(false);
		eneBtn.setBounds(enx, eny, 25, 25);
		eneBtn.setBackground(c);
		frame.add(eneBtn);
	}

	@Override
	public void run() {
		while (isRunning) {
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (isUp) {
				eny -= 10;
				if (eny <= 0) {
					isUp = false;
				}
			} else {
				eny += 10;
				if (eny >= 160) {
					isUp = true;

				}
			}
			if (((frame.xPlayer < enx && frame.xPlayer + 29 > enx)
					|| (enx <= frame.xPlayer && enx + (enw - 1) > frame.xPlayer))
					&& ((frame.yPlayer <= eny && frame.yPlayer + 29 > eny)
							|| (eny <= frame.yPlayer && eny + (enh - 1) > frame.yPlayer))) {
				// �ٽ� �¾ ��ǥ
				frame.xPlayer = 10;
				frame.yPlayer = 60;
				frame.btPlayer.setBounds(frame.xPlayer, frame.yPlayer, 30, 30);
				new Music("CanCrush.wav", 1500).start();

			}
			eneBtn.setBounds(enx, eny, 25, 25);
		}
	}
}