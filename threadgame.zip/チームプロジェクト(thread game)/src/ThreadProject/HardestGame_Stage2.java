package ThreadProject;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class HardestGame_Stage2 extends JFrame implements KeyListener, Runnable {
	JButton btPlayer, btTarget;
	MainPage mp;
	int xPlayer = 10;
	int yPlayer = 100;
	int xTarget = 550;
	int yTarget = 100;

	int count;
	int dCount;

	Thread th;
	boolean KeyUp = false;
	boolean KeyDown = false;
	boolean KeyLeft = false;
	boolean KeyRight = false;

	boolean isEnd = true;
	JLabel lbl;

	Music backgroundMusic = new Music("InGame.wav", 36000, true);

	public HardestGame_Stage2(MainPage mp) {
		this.mp = mp;
		setTitle("����� �����_Stage2");
		setSize(600, 300);
		setLayout(null);
		init();
		setResizable(false);
		setVisible(true);
		setLocationRelativeTo(null);
		add(btPlayer);
		btTarget.setText("Alive");
		add(btTarget);
	}

	void init() {
		backgroundMusic.start();
		setContentPane(new JLabel(new ImageIcon("Pepsi.jpg")));
		btPlayer = new JButton(new ImageIcon("PlayerPepsi.png"));
		btPlayer.setBorderPainted(false);
		btPlayer.setContentAreaFilled(false);
		btPlayer.setFocusable(false);
		btPlayer.setOpaque(false);
		btTarget = new JButton(new ImageIcon("TargetHumanDrink.png"));
		btTarget.setBorderPainted(false);
		btTarget.setContentAreaFilled(false);
		btTarget.setFocusable(false);
		btTarget.setOpaque(false);

		btTarget.setBounds(xTarget, yTarget, 30, 30);
		// �� ���� �κ�
		EneThread2_stage2 racene1 = new EneThread2_stage2(this, 130, 0, 20, 20, Color.BLACK, 8);
		racene1.start();
		EneThread2_stage2 racene2 = new EneThread2_stage2(this, 130, 90, 20, 20, Color.BLACK, 8);
		racene2.start();
		EneThread2_stage2 racene3 = new EneThread2_stage2(this, 130, 180, 20, 20, Color.BLACK, 8);
		racene3.start();
		EneThread2_stage2 racene4 = new EneThread2_stage2(this, 260, 0, 20, 20, Color.BLACK, 8);
		racene4.start();
		EneThread2_stage2 racene5 = new EneThread2_stage2(this, 260, 90, 20, 20, Color.BLACK, 8);
		racene5.start();
		EneThread2_stage2 racene6 = new EneThread2_stage2(this, 260, 180, 20, 20, Color.BLACK, 8);
		racene6.start();
		EneThread2_stage2 racene7 = new EneThread2_stage2(this, 390, 0, 20, 20, Color.BLACK, 8);
		racene7.start();
		EneThread2_stage2 racene8 = new EneThread2_stage2(this, 390, 90, 20, 20, Color.BLACK, 8);
		racene8.start();
		EneThread2_stage2 racene9 = new EneThread2_stage2(this, 390, 180, 20, 20, Color.BLACK, 8);
		racene9.start();

		EneThread3_stage2 backene1 = new EneThread3_stage2(this, 180, 50, 20, 20, Color.BLACK, 8);
		backene1.start();
		EneThread3_stage2 backene2 = new EneThread3_stage2(this, 180, 140, 20, 20, Color.BLACK, 8);
		backene2.start();
		EneThread3_stage2 backene3 = new EneThread3_stage2(this, 180, 230, 20, 20, Color.BLACK, 8);
		backene3.start();
		EneThread3_stage2 backene4 = new EneThread3_stage2(this, 310, 50, 20, 20, Color.BLACK, 8);
		backene4.start();
		EneThread3_stage2 backene5 = new EneThread3_stage2(this, 310, 140, 20, 20, Color.BLACK, 8);
		backene5.start();
		EneThread3_stage2 backene6 = new EneThread3_stage2(this, 310, 230, 20, 20, Color.BLACK, 8);
		backene6.start();
		EneThread3_stage2 backene7 = new EneThread3_stage2(this, 440, 50, 20, 20, Color.BLACK, 8);
		backene7.start();
		EneThread3_stage2 backene8 = new EneThread3_stage2(this, 440, 140, 20, 20, Color.BLACK, 8);
		backene8.start();
		EneThread3_stage2 backene9 = new EneThread3_stage2(this, 440, 230, 20, 20, Color.BLACK, 8);
		backene9.start();
		// �� ���� ��
		lbl = new JLabel();
		lbl.setBounds(450, 10, 500, 20);
		lbl.setText("��ī �ݶ�" + dCount + "�� ����");
		lbl.setForeground(Color.white);
		this.add(lbl);

		th = new Thread(this);
		th.start();

		this.addKeyListener(this);
		this.setFocusable(true);
	}

	public void KeyProcess() {
		// ������ ĳ���� ������ ������ ����
		// ������ �޾Ƶ��� Ű���� ��������
		// Ű �Է½ø��� 5��ŭ�� �̵��� ��Ų��.

		if (KeyUp == true)
			if (yPlayer >= 5) {
				yPlayer -= 3;
			}
		if (KeyDown == true)
			if (yPlayer <= 240) {
				yPlayer += 3;
			}
		if (KeyLeft == true)
			if (xPlayer >= 5) {
				xPlayer -= 3;
			}
		if (KeyRight == true)
			if (xPlayer <= 560) {
				xPlayer += 3;
			}
		btPlayer.setBounds(xPlayer, yPlayer, 20, 20);

	}

	public void GetTarget() {
		// Ÿ�� �ߺ� ȹ�� ����
		if (btTarget.getText() == "Alive") {

			// �浹����
			if (((xPlayer <= xTarget && xPlayer + 20 > xTarget) || (xTarget <= xPlayer && xTarget + 31 > xPlayer))
					&& ((yPlayer <= yTarget && yPlayer + 20 > yTarget)
							|| (yTarget <= yPlayer && yTarget + 31 > yPlayer))) {
				// "Alive"�϶��� �浹�����̹Ƿ� "Get"���� �ٲ㼭 ������ �������� ���ϰ� ����
				btTarget.setText("Get!");
				remove(btTarget);
				count += 1;
				if (count == 1) {
					// ������ �ݱ�
					isEnd = false;
					new Music("drink.wav", 12000).start();
					JOptionPane.showMessageDialog(this, "��! ��ô�!", "Ŭ����!", 3, new ImageIcon("Relax.jpg", "North"));
					backgroundMusic.remove();
					dispose();
					new HardestGame_Stage3(mp);
				}
				mp.btStage3.setEnabled(true);
				repaint();
				revalidate();
			}

		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = true;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = true;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = true;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = true;
			break;
		}
		if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			backgroundMusic.remove();
			dispose();
		}
		GetTarget();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = false;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = false;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = false;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = false;
			break;
		}
		GetTarget();
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (isEnd) {
			KeyProcess();
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

class EneThread2_stage2 extends Thread {
	boolean isLeft = true;
	boolean isUp = true;
	boolean isRunning = true;
	int etx, ety, etw, eth, etxMove, etyMove;

	HardestGame_Stage2 frame;
	JButton eneBtn;
	int speed;

	public EneThread2_stage2(HardestGame_Stage2 frame, int x, int y, int w, int h, Color c, int speed) {
		this.frame = frame;
		this.etx = x;
		this.ety = y;
		this.etw = w;
		this.eth = h;
		this.speed = speed;
		eneBtn = new JButton(new ImageIcon("EnemyCoca.png"));
		eneBtn.setBorderPainted(false);
		eneBtn.setContentAreaFilled(false);
		eneBtn.setFocusable(false);
		eneBtn.setOpaque(false);
		eneBtn.setBackground(c);
		eneBtn.setBounds(etx, ety, etw, eth);
		frame.add(eneBtn);
	}

	public void run() {
		// TODO Auto-generated method stub
		int x = etx;
		int y = ety;
		while (true) {
			// ó�� ��ǥ 2�� + �̵��� ��ġ ����ֱ�
			if (ety == y && etx >= x && etx < x + 50) {
				etx += 1;
			} else if (etx == x + 50 && ety < y + 50 && ety >= y) {
				ety += 1;
			} else if (ety == y + 50 && etx <= x + 50 && etx > x) {
				etx -= 1;
			} else if (etx == x && ety <= y + 50 && ety > y) {
				ety -= 1;
			}

			eneBtn.setBounds(etx, ety, 20, 20);
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (((frame.xPlayer < etx && frame.xPlayer + 19 > etx)
					|| (etx <= frame.xPlayer && etx + (etw - 1) > frame.xPlayer))
					&& ((frame.yPlayer <= ety && frame.yPlayer + 19 > ety)
							|| (ety <= frame.yPlayer && ety + (eth - 1) > frame.yPlayer))) {
				frame.dCount++;
				frame.lbl.setText("��ī �ݶ�" + frame.dCount + "�� ����");
				frame.xPlayer = 10;
				frame.yPlayer = 100;
				frame.btPlayer.setBounds(frame.xPlayer, frame.yPlayer, 20, 20);
				new Music("CanCrush.wav", 1500).start();

			}
		}

	}
}

class EneThread3_stage2 extends Thread {
	boolean isLeft = true;
	boolean isUp = true;
	boolean isRunning = true;
	int etx, ety, etw, eth, etxMove, etyMove;

	HardestGame_Stage2 frame;
	JButton eneBtn;
	int speed;

	public EneThread3_stage2(HardestGame_Stage2 frame, int x, int y, int w, int h, Color c, int speed) {
		this.frame = frame;
		this.etx = x;
		this.ety = y;
		this.etw = w;
		this.eth = h;
		this.speed = speed;
		eneBtn = new JButton(new ImageIcon("EnemyCoca.png"));
		eneBtn.setBorderPainted(false);
		eneBtn.setContentAreaFilled(false);
		eneBtn.setFocusable(false);
		eneBtn.setOpaque(false);
		eneBtn.setBackground(c);
		eneBtn.setBounds(etx, ety, etw, eth);
		frame.add(eneBtn);
	}

	public void run() {
		// TODO Auto-generated method stub
		int x = etx;
		int y = ety;
		while (true) {
			// ó�� ��ǥ 2�� + �̵��� ��ġ ����ֱ�
			if (ety == y && etx <= x && etx > x - 50) {
				etx -= 1;
			} else if (etx == x && ety < y && ety >= y - 50) {
				ety += 1;
			} else if (ety == y - 50 && etx >= x - 50 && etx < x) {
				etx += 1;
			} else if (etx == x - 50 && ety <= y && ety > y - 50) {
				ety -= 1;
			}

			eneBtn.setBounds(etx, ety, 20, 20);
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (((frame.xPlayer < etx && frame.xPlayer + 19 > etx)
					|| (etx <= frame.xPlayer && etx + (etw - 1) > frame.xPlayer))
					&& ((frame.yPlayer <= ety && frame.yPlayer + 19 > ety)
							|| (ety <= frame.yPlayer && ety + (eth - 1) > frame.yPlayer))) {
				frame.dCount++;
				frame.lbl.setText("��ī �ݶ�" + frame.dCount + "�� ����");
				frame.xPlayer = 10;
				frame.yPlayer = 100;
				frame.btPlayer.setBounds(frame.xPlayer, frame.yPlayer, 20, 20);
				new Music("CanCrush.wav", 1500).start();

			}
		}

	}
}
