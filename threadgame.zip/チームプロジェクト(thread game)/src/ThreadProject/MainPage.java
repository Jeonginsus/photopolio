package ThreadProject;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MainPage extends JFrame implements ActionListener, KeyListener {
	JButton btStart, btStageSelect, btClose, btStage1, btStage2, btStage3, btStage4, btStage5;
	HardestGame_Stage1 hs1;
	HardestGame_Stage2 hs2;
	HardestGame_Stage3 hs3;
	HardestGame_Stage4 hs4;
	HardestGame_Stage5 hs5;
	Music backgroundMusic = new Music("TitleBg.wav", 130000, true);

	public MainPage() {
		setSize(700, 580);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("����� �����");
		setLayout(null);
		this.getContentPane().setBackground(Color.black);
		setResizable(false);
		setLocationRelativeTo(null);

		backgroundMusic.start();

		this.setContentPane(new JLabel(new ImageIcon("BackGround.png")));

		btStart = new JButton(new ImageIcon("start.png"));
		btStageSelect = new JButton(new ImageIcon("Stage.png"));
		btClose = new JButton(new ImageIcon("Exit.png"));
		btStage1 = new JButton(new ImageIcon("Stage1.png"));
		btStage2 = new JButton(new ImageIcon("Stage2.png"));
		btStage3 = new JButton(new ImageIcon("Stage3.png"));
		btStage4 = new JButton(new ImageIcon("Stage4.png"));
		btStage5 = new JButton(new ImageIcon("Stage5.png"));

		btStart.setBounds(50, 30, 200, 150);
		btStageSelect.setBounds(50, 200, 200, 150);
		btClose.setBounds(50, 370, 200, 150);
		btStage1.setBounds(50, 10, 200, 150);
		btStage2.setBounds(50, 110, 200, 150);
		btStage3.setBounds(50, 210, 200, 150);
		btStage4.setBounds(50, 310, 200, 150);
		btStage5.setBounds(50, 410, 200, 150);

		btStart.addActionListener(this);
		btStageSelect.addActionListener(this);
		btClose.addActionListener(this);
		btStage1.addActionListener(this);
		btStage2.addActionListener(this);
		btStage3.addActionListener(this);
		btStage4.addActionListener(this);
		btStage5.addActionListener(this);

		// �߰��Ѻκ�**********************
		btStage2.setEnabled(false);
		btStage3.setEnabled(false);
		btStage4.setEnabled(false);
		btStage5.setEnabled(false);
		// �������**********************

		btStart.setBorderPainted(false);
		btStart.setContentAreaFilled(false);
		btStart.setFocusable(false);
		btStart.setOpaque(false);

		btStageSelect.setBorderPainted(false);
		btStageSelect.setContentAreaFilled(false);
		btStageSelect.setFocusable(false);
		btStageSelect.setOpaque(false);

		btClose.setBorderPainted(false);
		btClose.setContentAreaFilled(false);
		btClose.setFocusable(false);
		btClose.setOpaque(false);

		btStage1.setBorderPainted(false);
		btStage1.setContentAreaFilled(false);
		btStage1.setFocusable(false);
		btStage1.setOpaque(false);

		btStage2.setBorderPainted(false);
		btStage2.setContentAreaFilled(false);
		btStage2.setFocusable(false);
		btStage2.setOpaque(false);

		btStage3.setBorderPainted(false);
		btStage3.setContentAreaFilled(false);
		btStage3.setFocusable(false);
		btStage3.setOpaque(false);

		btStage4.setBorderPainted(false);
		btStage4.setContentAreaFilled(false);
		btStage4.setFocusable(false);
		btStage4.setOpaque(false);

		btStage5.setBorderPainted(false);
		btStage5.setContentAreaFilled(false);
		btStage5.setFocusable(false);
		btStage5.setOpaque(false);

		add(btStart);
		add(btStageSelect);
		add(btClose);

		addKeyListener(this);
		this.setFocusable(true);
		JLabel lblTitle = new JLabel(new ImageIcon("Title.png"));
		lblTitle.setBounds(350, -100, 350, 600);

		add(lblTitle);

		setVisible(true);
		repaint();
		revalidate();

	}

	public static void main(String[] args) {
		new MainPage();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btStart) {
			new Tutorial();
			backgroundMusic.remove();
		} else if (e.getSource() == btStageSelect) {
			this.remove(btStart);
			this.remove(btStageSelect);
			this.remove(btClose);
			add(btStage1);
			add(btStage2);
			add(btStage3);
			add(btStage4);
			add(btStage5);

			repaint();
			revalidate();
		} else if (e.getSource() == btClose) {
			System.exit(0);
			backgroundMusic.remove();
		} else if (e.getSource() == btStage1) {
			hs1 = new HardestGame_Stage1(this);
			backgroundMusic.remove();

		} else if (e.getSource() == btStage2) {
			hs2 = new HardestGame_Stage2(this);
			backgroundMusic.remove();

		} else if (e.getSource() == btStage3) {
			hs3 = new HardestGame_Stage3(this);
			backgroundMusic.remove();

		} else if (e.getSource() == btStage4) {
			hs4 = new HardestGame_Stage4(this);
			backgroundMusic.remove();

		} else if (e.getSource() == btStage5) {
			hs5 = new HardestGame_Stage5(this);
			backgroundMusic.remove();
		}

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {

			this.remove(btStage1);
			this.remove(btStage2);
			this.remove(btStage3);
			this.remove(btStage4);
			this.remove(btStage5);
			this.add(btStart);
			this.add(btStageSelect);
			this.add(btClose);

			repaint();
			revalidate();

		}
	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

}