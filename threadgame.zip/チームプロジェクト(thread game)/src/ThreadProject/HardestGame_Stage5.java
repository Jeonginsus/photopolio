package ThreadProject;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class HardestGame_Stage5 extends JFrame implements KeyListener, Runnable {
	JButton btPlayer;
	MainPage mp;

	int xPlayer = 210;
	int yPlayer = 420;
	int xTarget = 100;
	int yTarget = 10;
	int count;

	Thread th;
	// ���� ����
	TargetHuman c, c1, c2, c3, c4;

	JLabel lbl;
	int dCount;

	boolean KeyUp = false;
	boolean KeyDown = false;
	boolean KeyLeft = false;
	boolean KeyRight = false;

	boolean isEnd = true;
	
	Music backgroundMusic = new Music("InGame.wav", 36000, true);

	public HardestGame_Stage5(MainPage mp) {
		this.mp = mp;
		setTitle("����� �����_Stage5");
		setSize(500, 500);
		setLayout(null);
		init();
		setResizable(false);
		setVisible(true);
		setLocationRelativeTo(null);
		add(btPlayer);

	}

	void init() {
		backgroundMusic.start();
		setContentPane(new JLabel(new ImageIcon("Pepsi.jpg")));
		btPlayer = new JButton(new ImageIcon("PlayerPepsi.png"));
		btPlayer.setBorderPainted(false);
		btPlayer.setContentAreaFilled(false);
		btPlayer.setFocusable(false);
		btPlayer.setOpaque(false);
		// �� ���� �κ�
		EneThread2_stage5 ene1 = new EneThread2_stage5(this, 0, 0, 20, 20, Color.RED, 778);
		ene1.start();
		EneThread2_stage5 ene2 = new EneThread2_stage5(this, 430, 0, 20, 20, Color.RED, 778);
		ene2.start();
		EneThread2_stage5 ene3 = new EneThread2_stage5(this, 0, 380, 20, 20, Color.RED, 778);
		ene3.start();
		EneThread2_stage5 ene4 = new EneThread2_stage5(this, 430, 380, 20, 20, Color.RED, 778);
		ene4.start();
		EneThread2_stage5 ene5 = new EneThread2_stage5(this, 200, 200, 20, 20, Color.RED, 778);
		ene5.start();
		EneThread2_stage5 ene6 = new EneThread2_stage5(this, 190, 400, 20, 20, Color.RED, 778);
		ene6.start();

		EneThread3_stage5 bene1 = new EneThread3_stage5(this, 50, 50, 20, 20, Color.RED, 778);
		bene1.start();
		EneThread3_stage5 bene2 = new EneThread3_stage5(this, 480, 50, 20, 20, Color.RED, 778);
		bene2.start();
		EneThread3_stage5 bene3 = new EneThread3_stage5(this, 50, 430, 20, 20, Color.RED, 778);
		bene3.start();
		EneThread3_stage5 bene4 = new EneThread3_stage5(this, 480, 430, 20, 20, Color.RED, 778);
		bene4.start();
		EneThread3_stage5 bene5 = new EneThread3_stage5(this, 250, 250, 20, 20, Color.RED, 778);
		bene5.start();
		EneThread3_stage5 bene6 = new EneThread3_stage5(this, 240, 450, 20, 20, Color.RED, 778);
		bene6.start();
		// �� ���� ��

		th = new Thread(this);
		th.start();
		c = new TargetHuman(this, 20, 20);
		c1 = new TargetHuman(this, 450, 20);
		c2 = new TargetHuman(this, 450, 400);
		c3 = new TargetHuman(this, 20, 400);
		c4 = new TargetHuman(this, 220, 220);

		lbl = new JLabel("��ī �ݶ� " + dCount + "�� ����");
		lbl.setBounds(250, 10, 500, 20);
		lbl.setText("��ī �ݶ�" + dCount + "�� ����");
		lbl.setForeground(Color.white);
		add(lbl);

		this.addKeyListener(this);
		this.setFocusable(true);
	}

	public void KeyProcess() {
		// ������ ĳ���� ������ ������ ����
		// ������ �޾Ƶ��� Ű���� ��������
		// Ű �Է½ø��� 5��ŭ�� �̵��� ��Ų��.

		if (KeyUp == true)
			if (yPlayer >= 5) {
				yPlayer -= 5;
			}
		if (KeyDown == true)
			if (yPlayer <= 435) {
				yPlayer += 5;
			}
		if (KeyLeft == true)
			if (xPlayer >= 5) {
				xPlayer -= 5;
			}
		if (KeyRight == true)
			if (xPlayer <= 460) {
				xPlayer += 5;
			}
		btPlayer.setBounds(xPlayer, yPlayer, 20, 20);

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = true;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = true;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = true;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = true;
			break;
		}
		if(e.getKeyCode()==KeyEvent.VK_SPACE){
			backgroundMusic.remove();
	         dispose();
	      }
		c.GetTarget();
		c1.GetTarget();
		c2.GetTarget();
		c3.GetTarget();
		c4.GetTarget();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			KeyUp = false;
			break;
		case KeyEvent.VK_DOWN:
			KeyDown = false;
			break;
		case KeyEvent.VK_LEFT:
			KeyLeft = false;
			break;
		case KeyEvent.VK_RIGHT:
			KeyRight = false;
			break;
		}
		c.GetTarget();
		c1.GetTarget();
		c2.GetTarget();
		c3.GetTarget();
		c4.GetTarget();
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (isEnd) {
			KeyProcess();
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	
}

class TargetHuman {
	JButton btn;
	HardestGame_Stage5 frame;
	int x, y;

	public TargetHuman(HardestGame_Stage5 frame, int x, int y) {
		this.frame = frame;
		this.x = x;
		this.y = y;
		btn = new JButton(new ImageIcon("TargetHumanDrink.png"));

		btn.setBorderPainted(false);
		btn.setContentAreaFilled(false);
		btn.setFocusable(false);
		btn.setOpaque(false);

		btn.setText(" ");
		btn.setBounds(x, y, 30, 30);
		btn.setBackground(Color.yellow);
		frame.add(btn);

	}

	public void GetTarget() {
		if (btn.getText() == " ") {
			// �浹����
			if (((frame.xPlayer <= x && frame.xPlayer + 20 > x) || (x <= frame.xPlayer && x + 31 > frame.xPlayer))
					&& ((frame.yPlayer <= y && frame.yPlayer + 20 > y)
							|| (y <= frame.yPlayer && y + 31 > frame.yPlayer))) {
				frame.remove(btn);

				btn.setText("Get!");
				frame.count += 1;

				if (frame.count == 5) {
					// ������ �ݱ�
					frame.isEnd = false;
					new Music("drink.wav", 12000).start();
					JOptionPane.showMessageDialog(frame, "Ŭ����!");
					frame.backgroundMusic.remove();
					frame.dispose();
					new Ending();
				}
			}
			frame.repaint();
			frame.revalidate();

		}
	}
}

class EneThread2_stage5 extends Thread {
	boolean isLeft = true;
	boolean isUp = true;
	boolean isRunning = true;
	int etx, ety, etw, eth, etxMove, etyMove;

	HardestGame_Stage5 frame;
	JButton eneBtn;
	int speed;

	public EneThread2_stage5(HardestGame_Stage5 frame, int x, int y, int w, int h, Color c, int speed) {
		this.frame = frame;
		this.etx = x;
		this.ety = y;
		this.etw = w;
		this.eth = h;
		this.speed = speed;
		eneBtn = new JButton(new ImageIcon("EnemyCoca.png"));
		eneBtn.setBorderPainted(false);
		eneBtn.setContentAreaFilled(false);
		eneBtn.setFocusable(false);
		eneBtn.setOpaque(false);
		eneBtn.setBackground(c);
		eneBtn.setBounds(etx, ety, etw, eth);
		frame.add(eneBtn);
	}

	public void run() {
		// TODO Auto-generated method stub
		int x = etx;
		int y = ety;
		while (true) {
			// ó�� ��ǥ 2�� + �̵��� ��ġ ����ֱ�
			if (ety == y && etx >= x && etx < x + 50) {
				etx += 1;
			} else if (etx == x + 50 && ety < y + 50 && ety >= y) {
				ety += 1;
			} else if (ety == y + 50 && etx <= x + 50 && etx > x) {
				etx -= 1;
			} else if (etx == x && ety <= y + 50 && ety > y) {
				ety -= 1;
			}

			eneBtn.setBounds(etx, ety, 20, 20);
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (((frame.xPlayer < etx && frame.xPlayer + 19 > etx)
					|| (etx <= frame.xPlayer && etx + (etw - 1) > frame.xPlayer))
					&& ((frame.yPlayer <= ety && frame.yPlayer + 19 > ety)
							|| (ety <= frame.yPlayer && ety + (eth - 1) > frame.yPlayer))) {
				frame.dCount++;
				frame.lbl.setText("��ī �ݶ�" + frame.dCount + "�� ����");
				frame.xPlayer = 210;
				frame.yPlayer = 420;
				frame.btPlayer.setBounds(frame.xPlayer, frame.yPlayer, 20, 20);
				new Music("CanCrush.wav", 1500).start();
				frame.count = 0;
				frame.remove(frame.c.btn);
				frame.remove(frame.c1.btn);
				frame.remove(frame.c2.btn);
				frame.remove(frame.c3.btn);
				frame.remove(frame.c4.btn);
				frame.add(frame.c.btn);
				frame.c.btn.setText(" ");
				frame.add(frame.c1.btn);
				frame.c1.btn.setText(" ");
				frame.add(frame.c2.btn);
				frame.c2.btn.setText(" ");
				frame.add(frame.c3.btn);
				frame.c3.btn.setText(" ");
				frame.add(frame.c4.btn);
				frame.c4.btn.setText(" ");
			}
		}

	}
}

class EneThread3_stage5 extends Thread {
	boolean isLeft = true;
	boolean isUp = true;
	boolean isRunning = true;
	int etx, ety, etw, eth, etxMove, etyMove;

	HardestGame_Stage5 frame;
	JButton eneBtn;
	int speed;

	public EneThread3_stage5(HardestGame_Stage5 frame, int x, int y, int w, int h, Color c, int speed) {
		this.frame = frame;
		this.etx = x;
		this.ety = y;
		this.etw = w;
		this.eth = h;
		this.speed = speed;
		eneBtn = new JButton(new ImageIcon("EnemyCoca.png"));
		eneBtn.setBorderPainted(false);
		eneBtn.setContentAreaFilled(false);
		eneBtn.setFocusable(false);
		eneBtn.setOpaque(false);
		eneBtn.setBackground(c);
		eneBtn.setBounds(etx, ety, etw, eth);
		frame.add(eneBtn);
	}

	public void run() {
		// TODO Auto-generated method stub
		int x = etx;
		int y = ety;
		while (true) {
			// ó�� ��ǥ 2�� + �̵��� ��ġ ����ֱ�
			if (ety == y && etx <= x && etx > x - 50) {
				etx -= 1;
			} else if (etx == x && ety < y && ety >= y - 50) {
				ety += 1;
			} else if (ety == y - 50 && etx >= x - 50 && etx < x) {
				etx += 1;
			} else if (etx == x - 50 && ety <= y && ety > y - 50) {
				ety -= 1;
			}

			eneBtn.setBounds(etx, ety, 20, 20);
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (((frame.xPlayer < etx && frame.xPlayer + 19 > etx)
					|| (etx <= frame.xPlayer && etx + (etw - 1) > frame.xPlayer))
					&& ((frame.yPlayer <= ety && frame.yPlayer + 19 > ety)
							|| (ety <= frame.yPlayer && ety + (eth - 1) > frame.yPlayer))) {
				frame.dCount++;

				frame.lbl.setText("��ī �ݶ�" + frame.dCount + "�� ����");
				frame.xPlayer = 210;
				frame.yPlayer = 420;
				frame.btPlayer.setBounds(frame.xPlayer, frame.yPlayer, 20, 20);
				new Music("CanCrush.wav", 1500).start();
				frame.count = 0;
				frame.remove(frame.c.btn);
				frame.remove(frame.c1.btn);
				frame.remove(frame.c2.btn);
				frame.remove(frame.c3.btn);
				frame.remove(frame.c4.btn);
				frame.add(frame.c.btn);
				frame.c.btn.setText(" ");
				frame.add(frame.c1.btn);
				frame.c1.btn.setText(" ");
				frame.add(frame.c2.btn);
				frame.c2.btn.setText(" ");
				frame.add(frame.c3.btn);
				frame.c3.btn.setText(" ");
				frame.add(frame.c4.btn);
				frame.c4.btn.setText(" ");

			}
		}

	}
}