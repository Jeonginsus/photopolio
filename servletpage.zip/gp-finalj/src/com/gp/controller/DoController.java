package com.gp.controller;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gp.dao.bannerDAO;
import com.gp.dao.memberDAO;
import com.gp.dao.noticeDAO;
import com.gp.dao.productDAO;
import com.gp.dao.qnaDAO;
import com.gp.dao.reservationinfoDAO;
import com.gp.dao.reviewDAO;
import com.gp.dto.bannerDTO;
import com.gp.dto.memberDTO;
import com.gp.dto.noticeDTO;
import com.gp.dto.productDTO;
import com.gp.dto.qnaDTO;
import com.gp.dto.reservationinfoDTO;
import com.gp.dto.reviewDTO;

/**
 * Servlet implementation class DoController
 */
@WebServlet("*.do")
public class DoController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DoController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		actionDo(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		actionDo(request, response);
	}

	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String command = uri.substring(conPath.length());
		String viewPage = null;
		request.setCharacterEncoding("utf-8");
		
		if (command.equals("/main.do")) {
			productDAO product_dao = new productDAO();
			ArrayList<String> product_vector = product_dao.selectTheme();
			
			bannerDAO bannder_dao = new bannerDAO();
			Vector<bannerDTO> banner_vector = bannder_dao.selectAll();
			
			request.setAttribute("themes", product_vector);
			request.setAttribute("banners", banner_vector);
			viewPage = "index.jsp";
		} else if (command.equals("/login.do")) {
			viewPage = "login.jsp";
		} else if (command.equals("/loginproc.do")) {
			String email = request.getParameter("id");
			String password = request.getParameter("pw");
			memberDAO dao = new memberDAO();
			memberDTO dto = new memberDTO();
			dto.setEmail(email);
			dto.setPassword(password);
			
			int result = dao.login(dto);
			
			if (result > 0) {
				request.getSession().setAttribute("login_email", email);
				String rank = dao.getRank(dto);
				request.getSession().setAttribute("login_rank", rank);
				viewPage = "main.do";
				response.sendRedirect(viewPage);
				return;
			} else {
				request.setAttribute("loginfail", "true");
				viewPage = "login.jsp";
			}
		} else if (command.equals("/logoutproc.do")) {
			request.getSession().setAttribute("login_email", null);
			request.getSession().setAttribute("login_rank", null);
			viewPage = "main.do";
			response.sendRedirect(viewPage);
			return;
		} else if (command.equals("/join.do")) {
			viewPage = "join.jsp";
		} else if (command.equals("/korea.do")) {
			String location = ((String)request.getParameter("location") == null) ? "부산" : (String)request.getParameter("location");
			productDAO product_dao = new productDAO();
			ArrayList<productDTO> product_list = product_dao.selectLoaction(location);
			
			request.setAttribute("product_list", product_list);
			viewPage = "korea.jsp";
		} else if (command.equals("/mypage.do")) {
			String email = (String) request.getSession().getAttribute("login_email");
			
			if (email == null) {
				viewPage = "login.jsp";
			} else {
				memberDAO dao = new memberDAO();
				Vector<memberDTO> v = dao.logindata(email);
				
				request.setAttribute("logindata", v);
				viewPage = "mypage.jsp";
			}
		} else if (command.equals("/task.do")) {
			String email = (String) request.getSession().getAttribute("login_email"); 
			memberDAO member_dao = new memberDAO();
			Vector<memberDTO> member_vector = member_dao.logindata(email);
			
			productDAO product_dao = new productDAO();
			int idx = Integer.parseInt((String) request.getParameter("idx"));
			Vector<productDTO> product_vector = product_dao.selectAny(idx);
			
			request.setAttribute("member_vector", member_vector);
			request.setAttribute("product_vector", product_vector);
			viewPage = "task.jsp";
		} else if (command.equals("/taskproc.do")) {
			int event1 = ((String)request.getParameter("trduseinfo") == null) ? 0 : 1;
			int event2 = ((String)request.getParameter("EMSservice") == null) ? 0 : 1;
			reservationinfoDAO dao = new reservationinfoDAO();
			reservationinfoDTO dto = new reservationinfoDTO();
			dto.setMembersidx(Integer.parseInt((String)request.getParameter("member_idx")));
			dto.setProductidx(Integer.parseInt((String)request.getParameter("product_idx")));
			dto.setEvent1(event1);
			dto.setEvent2(event2);
			dto.setName(request.getParameter("name"));
			dto.setEmail(request.getParameter("email"));
			dto.setNationalitynum(request.getParameter("frontHP"));
			dto.setPhonenum(request.getParameter("backHP"));
			dto.setDateofuse(request.getParameter("dateofuse"));
			dto.setAccompany(request.getParameter("together"));
			dto.setAmount(Integer.parseInt((String)request.getParameter("amount")));
			int result = dao.insert(dto);
			
			if (result > 0) {
				request.setAttribute("resv", "true");
			} else {
				request.setAttribute("resv", "false");
			}
			viewPage = "main.do";
			//response.sendRedirect(viewPage);
			//return;
		} else if (command.equals("/notice-main.do")) {
			noticeDAO dao = new noticeDAO();
			Vector<noticeDTO> vector = dao.selectAny();
			
			request.setAttribute("notice_vector", vector);
			viewPage = "notice-main.jsp";
		} else if (command.equals("/notice-qna.do")) {
			String category = "";
			int curr = -1;
			
			if (request.getParameter("curr") == null) {
				curr = 1;
			} else {
				curr = Integer.parseInt((String) request.getParameter("curr"));
			}
			
			if (curr == 1) {
				curr = 0;
			} else {
				curr = (curr-1) * 10;
			}
			
			try {
				category = URLDecoder.decode(request.getParameter("category"));
			} catch (Exception e) {
				category = "여행상품";
			}
			
			Vector<qnaDTO> vector = new Vector<>();
			qnaDAO dao = new qnaDAO();
			
			vector = dao.selectCategory(category, curr);
			request.setAttribute("qna_vector", vector);
			
			viewPage = "notice-qna.jsp";
		} else if (command.equals("/notice-qnaWrite.do")) {
			viewPage = "notice-qnaWrite.jsp";
		} else if (command.equals("/notice-qnaWriteProc.do")) {
			qnaDTO dto = new qnaDTO();
			dto.setTitle(request.getParameter("title"));
			dto.setContent(request.getParameter("content"));
			
			String categorys[] = request.getParameterValues("category");
			String category = "";
			for (String temp : categorys)
				category = temp;
			dto.setCategory(category);
			
			qnaDAO dao = new qnaDAO();
			int result = dao.insert(dto);
			
			if (result > 0) {
				request.setAttribute("qnawrite", "true");
				category = URLEncoder.encode(category);
				viewPage = "notice-qna.do?category=" + category;
			} else {
				request.setAttribute("qnawrite", "false");
				viewPage = "notice-qna.do";
			}
		} else if (command.equals("/notice-qnaUpdate.do")) {
			qnaDTO dto = new qnaDTO();
			dto.setIdx(Integer.parseInt((String)request.getParameter("idx")));
			qnaDAO dao = new qnaDAO();
			Vector<qnaDTO> vector = dao.selectOne(dto);
			request.setAttribute("qnadetail", vector);
			
			viewPage = "notice-qnaUpdate.jsp";
		} else if (command.equals("/notice-qnaUpdateProc.do")) {
			qnaDTO dto = new qnaDTO();
			dto.setIdx(Integer.parseInt((String) request.getParameter("idx")));
			dto.setTitle(request.getParameter("title"));
			dto.setContent(request.getParameter("content"));
			
			String categorys[] = request.getParameterValues("category");
			String category = "";
			for (String temp : categorys)
				category = temp;
			dto.setCategory(category);
			
			qnaDAO dao = new qnaDAO();
			int result = dao.update(dto);
			
			if (result > 0) {
				request.setAttribute("qnaupate", "true");
				category = URLEncoder.encode(category);
				viewPage = "notice-qna.do?category=" + category;
			} else {
				request.setAttribute("qnaupate", "false");
				viewPage = "notice-qna.do";
			}
		} else if (command.equals("/notice-qnaDeleteProc.do")) {
			qnaDTO dto = new qnaDTO();
			dto.setIdx(Integer.parseInt(request.getParameter("idx")));
			
			qnaDAO dao = new qnaDAO();
			int result = dao.delete(dto);
			
			if (result > 0) {
				request.setAttribute("qnadelete", "true");
			} else {
				request.setAttribute("qnadelete", "false");
			}
			
			viewPage = "notice-qna.do";
		} else if (command.equals("/insertprocess.do")){
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			String name = request.getParameter("name");
			String phone = request.getParameter("phone");
			int event = (request.getParameter("event") == null) ? 0 : 1;
			
			memberDTO dto = new memberDTO();
			dto.setEmail(email);
			dto.setPassword(password);
			dto.setName(name);
			dto.setPhone(phone);
			dto.setEvent(event);
			
			memberDAO dao = new memberDAO();
			int result = dao.insert(dto);
			
			if (result > 0)
				request.setAttribute("join", "yes");
			
			viewPage = "index.jsp";			
		} else if (command.equals("/member-update.do")) {
			String email = (String) request.getSession().getAttribute("login_email");
			
			if (email == null) {
				viewPage = "login.jsp";
			} else {
				memberDAO dao = new memberDAO();
				Vector<memberDTO> v = dao.logindata(email);
				
				request.setAttribute("logindata", v);
				viewPage = "member-update.jsp";
			}
		} else if (command.equals("/member-updateproc.do")) {
			String email = (String) request.getParameter("email");
			String password = (String) request.getParameter("password");
			String phone = (String) request.getParameter("phone");
			String banks[] = request.getParameterValues("bank");
			String bank = "";
			String account = "";
			
			if (banks == null) { }
			else {
				 for(String temp : banks) {
					 bank = temp;
				 }
			}
			
			memberDTO dto = new memberDTO();
			dto.setEmail(email);
			dto.setPassword(password);
			dto.setPhone(phone);
			dto.setBank(bank);
			dto.setAccount(account);
			
			memberDAO dao = new memberDAO();
			int result = dao.member_update(dto);
			
			if (result > 0) {
				request.setAttribute("updateproc", "true");
			} else {
				request.setAttribute("updateproc", "false");
			}
			
			viewPage = "mypage.do";
			response.sendRedirect(viewPage);
			return;
		} else if (command.equals("/noticeDe.do")) {
			viewPage = "noticeDe.jsp";
			String curr = request.getParameter("curr");
			if(curr==null) {
				curr = 1+"";
			}
			noticeDAO nodao = new noticeDAO();
			Vector<noticeDTO> v = nodao.selectAll(curr);
			request.setAttribute("result", v);
		} else if (command.equals("/noticeWrite.do")) {
			viewPage = "noticeWrite.jsp";
		} else if (command.equals("/noticeWriteProc.do")) {
			String title = request.getParameter("title");
			String content = request.getParameter("content");
			noticeDAO nodao = new noticeDAO();
			int result = nodao.noticeWriteProc(title, content);
			if(result==1) {
				viewPage = "/noticeDe.do";
			}
		} else if (command.equals("/noticeContent.do")) {
			viewPage = "noticeContent.jsp";
			String idx = request.getParameter("idx");
			noticeDAO nodao = new noticeDAO();
			noticeDTO v = nodao.selectOne(idx);
			request.setAttribute("result", v);
		} else if (command.equals("/noticeToNext.do")) {
			String where = request.getParameter("where"); //update, delete, back
			String idx="";
			if(where.equals("update")) {
				idx = request.getParameter("idx");
				noticeDAO nodao = new noticeDAO();
				noticeDTO dto = nodao.selectOne(idx);
				request.setAttribute("result", dto);
				viewPage = "/noticeUpdate.jsp";
			} else if(where.equals("delete")) {
				idx = request.getParameter("idx");
				noticeDAO nodao = new noticeDAO();
				int result = nodao.selectDelete(idx);
				if(result==1) {
					viewPage = "/noticeDe.do";
				}
			} else if(where.equals("back")) {
				viewPage = "/noticeDe.do";
			}
		} else if (command.equals("/noticeUpdateProc.do")) {
			String idx = request.getParameter("idx");
			String title = request.getParameter("title");
			String content = request.getParameter("content");
			noticeDAO nodao = new noticeDAO();
			int result = nodao.noticeUpdateProc(idx, title, content);
			if(result==1) {
				viewPage = "/noticeDe.do";
			}
		} else if (command.equals("/management.do")) {
			reservationinfoDAO reservation_dao = new reservationinfoDAO();
			Vector<reservationinfoDTO> reservation_vector = reservation_dao.reservationinfo_Select();
			
			reviewDAO review_dao = new reviewDAO();
			Vector<reviewDTO> review_vector = review_dao.review_Select();
			
			bannerDAO banner_dao = new bannerDAO();
			Vector<bannerDTO> banner_vector = banner_dao.selectAll();
			
			productDAO product_dao = new productDAO();
			Vector<productDTO> product_vector = product_dao.selectAll();
			
			request.setAttribute("reservation", reservation_vector);
			request.setAttribute("review", review_vector);
			request.setAttribute("banner", banner_vector);
			request.setAttribute("product", product_vector);
			viewPage = "admin.jsp";
		} else if (command.equals("/detail.do")) {
			int idx = Integer.parseInt((String)request.getParameter("idx"));
			reviewDAO review_dao = new reviewDAO();
			int review_cnt = review_dao.selectCnt(idx);
			Vector<reviewDTO> review_vector = review_dao.selectAny(idx);
					
			productDAO product_dao = new productDAO();
			Vector<productDTO> product_vector = product_dao.selectAny(idx);
			
			request.setAttribute("product_vector", product_vector);
			request.setAttribute("review_vector", review_vector);
			request.setAttribute("review_cnt", review_cnt);
			viewPage = "detail.jsp";
		} else if (command.equals("/notice-persnal.do")) {
			viewPage = "notice-persnal.jsp";
		}

		// 포워딩 구성 해당 viewPage로...
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);
	}
}