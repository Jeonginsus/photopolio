package com.gp.dto;

public class reservationinfoDTO {
	private int idx;
	private int membersidx;
	private int productidx;
	private int amount;
	private String dateofuse;
	private String name;
	private String email;
	private String nationalitynum;
	private String phonenum;
	private String dateofresev;
	private String accompany;
	private int event1;
	private int event2;
	
	public int getIdx() { return idx; }
	public void setIdx(int idx) { this.idx = idx; }
	
	public int getMembersidx() { return membersidx; }
	public void setMembersidx(int membersidx) { this.membersidx = membersidx; }
	
	public int getProductidx() { return productidx; }
	public void setProductidx(int productidx) { this.productidx = productidx; }
	
	public int getAmount() { return amount; }
	public void setAmount(int amount) { this.amount = amount; }
	
	public String getDateofuse() { return dateofuse; }
	public void setDateofuse(String dateofuse) { this.dateofuse = dateofuse; }
	
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	
	public String getEmail() { return email; }
	public void setEmail(String email) { this.email = email; }
	
	public String getNationalitynum() { return nationalitynum; }
	public void setNationalitynum(String nationalitynum) { this.nationalitynum = nationalitynum; }
	
	public String getPhonenum() { return phonenum; }
	public void setPhonenum(String phonenum) { this.phonenum = phonenum; }
	
	public String getDateofresev() { return dateofresev; }
	public void setDateofresev(String dateofresev) { this.dateofresev = dateofresev; }
	
	public String getAccompany() { return accompany; }
	public void setAccompany(String accompany) { this.accompany = accompany; }
	
	public int getEvent1() { return event1; }
	public void setEvent1(int event1) { this.event1 = event1; }
	
	public int getEvent2() { return event2; }
	public void setEvent2(int event2) { this.event2 = event2; }
}