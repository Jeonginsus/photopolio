package com.gp.dto;

public class personal_questionDTO {
	private int idx;
	private int member_idx;
	private String title;
	private String content;
	private String answer;
	
	public int getIdx() { return idx; }
	public void setIdx(int idx) { this.idx = idx; }
	
	public int getMember_idx() { return member_idx; }
	public void setMember_idx(int member_idx) { this.member_idx = member_idx; }
	
	public String getTitle() { return title; }
	public void setTitle(String title) { this.title = title; }
	
	public String getContent() { return content; }
	public void setContent(String content) { this.content = content; }
	
	public String getAnswer() { return answer; }
	public void setAnswer(String answer) { this.answer = answer; }
}