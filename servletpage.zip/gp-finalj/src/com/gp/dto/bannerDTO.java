package com.gp.dto;

public class bannerDTO {
	private int idx;
	private String directory;
	
	public int getIdx() { return idx; }
	public void setIdx(int idx) { this.idx = idx; }
	
	public String getDirectory() { return directory; }
	public void setDirectory(String directory) { this.directory = directory; }	
}