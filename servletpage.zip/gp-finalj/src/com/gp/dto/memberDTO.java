package com.gp.dto;

public class memberDTO {
	private int idx;
	private String email;
	private String password;
	private String rank;
	private String name;
	private String phone;
	private int event;
	private String bank;
	private String account;
	
	public int getIdx() { return idx; }
	public void setIdx(int idx) { this.idx = idx; }

	public String getEmail() { return email; }
	public void setEmail(String email) { this.email = email; }

	public String getPassword() { return password; }
	public void setPassword(String password) { this.password = password; }
	
	public String getRank() { return rank; }
	public void setRank(String rank) { this.rank = rank; }

	public String getName() { return name; }
	public void setName(String name) { this.name = name; }

	public String getPhone() { return phone; }
	public void setPhone(String phone) { this.phone = phone; }

	public int getEvent() { return event; }
	public void setEvent(int event) { this.event = event; }
	
	public String getBank() { return bank; }
	public void setBank(String bank) { this.bank = bank; }
	
	public String getAccount() { return account; }
	public void setAccount(String account) {this.account = account; }
}