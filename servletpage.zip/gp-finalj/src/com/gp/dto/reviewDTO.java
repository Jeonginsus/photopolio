package com.gp.dto;

public class reviewDTO {
	private int idx;
	private int product_idx;
	private int member_idx;
	private String content;
	private String write_date;
	
	public int getIdx() { return idx; }
	public void setIdx(int idx) { this.idx = idx; }
	
	public int getProduct_idx() { return product_idx; }
	public void setProduct_idx(int product_idx) { this.product_idx = product_idx; }
	
	public int getMember_idx() { return member_idx; }
	public void setMember_idx(int member_idx) { this.member_idx = member_idx; }
	
	public String getContent() { return content; }
	public void setContent(String content) { this.content = content; }
	
	public String getWrite_date() { return write_date; }
	public void setWrite_date(String write_date) { this.write_date = write_date; }
}