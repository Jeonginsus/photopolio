package com.gp.dto;

public class productDTO {
	private int idx;
	private String name;
	private int price;
	private String image_directory;
	private String introduce;
	private String theme;
	
	public int getIdx() { return idx; }
	public void setIdx(int idx) { this.idx = idx; }
	
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	
	public int getPrice() { return price; }
	public void setPrice(int price) { this.price = price; }
	
	public String getImage_directory() { return image_directory; }
	public void setImage_directory(String image_directory) { this.image_directory = image_directory; }
	
	public String getIntroduce() { return introduce; }
	public void setIntroduce(String introduce) { this.introduce = introduce; }
	
	public String getTheme() { return theme; }
	public void setTheme(String theme) { this.theme = theme; }
}