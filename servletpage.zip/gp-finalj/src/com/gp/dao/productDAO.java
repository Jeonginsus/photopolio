package com.gp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Vector;

import com.gp.dto.productDTO;
import com.gp.dto.qnaDTO;

public class productDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	int result = 0;
	DBConnectionMgr pool = DBConnectionMgr.getInstance();
	
	public Vector<productDTO> selectAll() {
		Vector<productDTO> vector = new Vector<>();
		
		try {
			conn = pool.getConnection();
			String sql = "SELECT * FROM product";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();

			while (rs.next()) {
				productDTO dto = new productDTO();
				dto.setIdx(rs.getInt(1));
				dto.setName(rs.getString(2));
				dto.setPrice(rs.getInt(3));
				dto.setImage_directory(rs.getString(4));
				dto.setIntroduce(rs.getString(5));
				dto.setTheme(rs.getString(6));
				
				vector.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return vector;
	}
	
	public Vector<productDTO> selectAny(int idx) {
		Vector<productDTO> vector = new Vector<>();
		
		try {
			conn = pool.getConnection();
			String sql = "SELECT * FROM product where idx=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			
			rs = pstmt.executeQuery();

			while (rs.next()) {
				productDTO dto = new productDTO();
				dto.setIdx(rs.getInt(1));
				dto.setName(rs.getString(2));
				dto.setPrice(rs.getInt(3));
				dto.setImage_directory(rs.getString(4));
				dto.setIntroduce(rs.getString(5));
				dto.setTheme(rs.getString(6));
				
				vector.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return vector;
	}
	
	public String getTheme(int idx) {
		String theme = "";
		
		try {
			conn = pool.getConnection();

			String query = "select * from product where idx=?";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, idx);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				theme = rs.getString(5);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return theme;
	}

	public ArrayList<String> selectTheme() {
		// TODO Auto-generated method stub
		ArrayList<String> themes = new ArrayList<>();
		
		try {
			conn = pool.getConnection();
			String sql = "SELECT SUBSTRING_INDEX(theme, '/', -1) AS theme FROM product GROUP BY SUBSTRING_INDEX(theme, '/', -1)";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				themes.add(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return themes;
	}
	
	public Vector<productDTO> findTheme(String theme) {
		Vector<productDTO> vector = new Vector<>();
		
		try {
			conn = pool.getConnection();
			String sql = "SELECT * FROM product WHERE theme LIKE ? ORDER BY rand() LIMIT 6";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+theme+"%");
			rs = pstmt.executeQuery();

			while (rs.next()) {
				productDTO dto = new productDTO();
				dto.setIdx(rs.getInt(1));
				dto.setName(rs.getString(2));
				dto.setPrice(rs.getInt(3));
				dto.setImage_directory(rs.getString(4));
				dto.setIntroduce(rs.getString(5));
				dto.setTheme(rs.getString(6));
				
				vector.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return vector;
	}

	public ArrayList<productDTO> selectLoaction(String location) {
		// TODO Auto-generated method stub
		ArrayList<productDTO> list = new ArrayList<>();
		
		try {
			conn = pool.getConnection();
			String sql = "SELECT * FROM product WHERE theme LIKE ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+location+"%");
			rs = pstmt.executeQuery();

			while (rs.next()) {
				productDTO dto = new productDTO();
				dto.setIdx(rs.getInt(1));
				dto.setName(rs.getString(2));
				dto.setPrice(rs.getInt(3));
				dto.setImage_directory(rs.getString(4));
				dto.setIntroduce(rs.getString(5));
				dto.setTheme(rs.getString(6));
				
				list.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return list;
	}
	
	public int insert(productDTO dto) {
		// TODO Auto-generated method stub
		try {
			conn = pool.getConnection();

			String query = "INSERT INTO product(name, price, image_directory, introduce, theme) VALUES(?,?,?,?,?)";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1,dto.getName());
			pstmt.setInt(2, dto.getPrice());
			pstmt.setString(3, dto.getImage_directory());
			pstmt.setString(4, dto.getIntroduce());
			pstmt.setString(5, dto.getTheme());
			
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}
		
		return result;
	}
}