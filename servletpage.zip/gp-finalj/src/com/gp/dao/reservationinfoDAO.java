package com.gp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import com.gp.dto.reservationinfoDTO;

public class reservationinfoDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	int result = 0;
	DBConnectionMgr pool = DBConnectionMgr.getInstance();
	
	public Vector<reservationinfoDTO> reservationinfo_Select(){
		Vector<reservationinfoDTO> v = new Vector<>();
		try {
			conn = pool.getConnection();
			String sql = "select * from reservationinfo";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
				reservationinfoDTO dto = new reservationinfoDTO();
				dto.setIdx(rs.getInt("idx"));
				dto.setMembersidx(rs.getInt("membersidx"));
				dto.setProductidx(rs.getInt("productidx"));
				dto.setAmount(rs.getInt("amount"));
				dto.setDateofuse(rs.getString("dateofuse"));
				dto.setName(rs.getString("NAME"));
				dto.setEmail(rs.getString("email"));
				dto.setNationalitynum(rs.getString("nationalitynum"));
				dto.setPhonenum(rs.getString("phonenum"));
				dto.setDateofresev(rs.getString("dateofresev"));
				dto.setAccompany(rs.getString("accompany"));
				dto.setEvent1(rs.getInt("EVENT1"));
				dto.setEvent2(rs.getInt("EVENT2"));
				v.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return v;
	}
	
	public int reservationinfo_Delete(String idx){
		try {
			conn = pool.getConnection();
			String sql = "delete from reservationinfo where idx=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(idx));
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}
		
		return result;
	}

	public int insert(reservationinfoDTO dto) {
		// TODO Auto-generated method stub
		try {
			conn = pool.getConnection();
			String sql = "insert into reservationinfo(membersidx, productidx, amount, dateofuse, name, email, nationalitynum, phonenum, dateofresev, accompany, event1, event2)"
					+ "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dto.getMembersidx());
			pstmt.setInt(2, dto.getProductidx());
			pstmt.setInt(3, dto.getAmount());
			pstmt.setString(4, dto.getDateofuse());
			pstmt.setString(5, dto.getName());
			pstmt.setString(6, dto.getEmail());
			pstmt.setString(7, dto.getNationalitynum());
			pstmt.setString(8, dto.getPhonenum());
			
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String now = format.format(date);
			
			pstmt.setString(9, now);
			pstmt.setString(10, dto.getAccompany());
			pstmt.setInt(11, dto.getEvent1());
			pstmt.setInt(12, dto.getEvent2());
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}
		
		return result;
	}
}