package com.gp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import com.gp.dto.bannerDTO;

public class bannerDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	int result = 0;
	DBConnectionMgr pool = DBConnectionMgr.getInstance();
	
	public Vector<bannerDTO> selectAll() {
		Vector<bannerDTO> v = new Vector<>();
		try {
			conn = pool.getConnection();
			String sql = "select * from banner";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				bannerDTO dto = new bannerDTO();
				dto.setIdx(rs.getInt(1));
				dto.setDirectory(rs.getString(2));
				
				v.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		return v;
	}
	
	public int banner_Delete(String idx) {
		try {
			conn = pool.getConnection();
			String sql = "delete from banner where idx=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(idx));
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}

		return result;
	}
	
	public int insert(String fileName) {
		try {
			conn = pool.getConnection();
			String sql = "insert into banner(idx, directory) values(null, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, fileName);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}

		return result;
	}
}