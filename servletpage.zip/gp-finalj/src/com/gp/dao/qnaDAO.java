package com.gp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import com.gp.dto.qnaDTO;

public class qnaDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	int result = 0;
	DBConnectionMgr pool = DBConnectionMgr.getInstance();
	
	public Vector<qnaDTO> selectCategory(String category, int curr) {
		// TODO Auto-generated method stub
		Vector<qnaDTO> v = new Vector<>();
		int pageSize = 10;
		
		try {
			conn = pool.getConnection();
			String sql = "SELECT * FROM qna where category=? ORDER BY idx DESC LIMIT ?, ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, category);
			pstmt.setInt(2, curr);
			pstmt.setInt(3, pageSize);
			
			rs = pstmt.executeQuery();

			while (rs.next()) {
				qnaDTO dto = new qnaDTO();
				dto.setIdx(rs.getInt(1));
				dto.setTitle(rs.getString(2));
				dto.setContent(rs.getString(3));
				
				v.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		return v;
	}

	public int insert(qnaDTO dto) {
		// TODO Auto-generated method stub
		try {
			conn = pool.getConnection();

			String query = "INSERT INTO qna(title, content, category) VALUES(?,?,?)";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getContent());
			pstmt.setString(3, dto.getCategory());
			
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}
		
		return result;
	}

	public int delete(qnaDTO dto) {
		// TODO Auto-generated method stub
		try {
			conn = pool.getConnection();

			String query = "DELETE FROM qna WHERE idx=?";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, dto.getIdx());
			
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}
		
		return result;
	}

	public Vector<qnaDTO> selectOne(qnaDTO dto) {
		// TODO Auto-generated method stub
		Vector<qnaDTO> v = new Vector<>();
		
		try {
			conn = pool.getConnection();
			String sql = "select * from qna where idx=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dto.getIdx());
			rs = pstmt.executeQuery();

			if (rs.next()) {
				qnaDTO qna = new qnaDTO();
				qna.setIdx(rs.getInt(1));
				qna.setTitle(rs.getString(2));
				qna.setContent(rs.getString(3));
				qna.setCategory(rs.getString(3));
				
				v.add(qna);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		return v;
	}

	public int update(qnaDTO dto) {
		// TODO Auto-generated method stub
		try {
			conn = pool.getConnection();

			String query = "update qna set title=?, content=?, category=? where idx=?";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getContent());
			pstmt.setString(3, dto.getCategory());
			pstmt.setInt(4, dto.getIdx());
			
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}
		
		return result;
	}
	
	public int selectCnt(String category) {
		try {
			conn = pool.getConnection();
			String sql = "SELECT count(*) from qna where category=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, category);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				result = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		return result;
	}
}