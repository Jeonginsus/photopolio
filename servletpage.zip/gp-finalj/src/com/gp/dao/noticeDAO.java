package com.gp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.gp.dto.noticeDTO;

public class noticeDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	int result = 0;
	DBConnectionMgr pool = DBConnectionMgr.getInstance();

	public Vector<noticeDTO> selectAll(String curr) {
		Vector<noticeDTO> v = new Vector<>();
		int currpage = Integer.parseInt(curr);
		int pageSize = 10;
		currpage = (currpage - 1) * pageSize;

		try {
			conn = pool.getConnection();
			String sql = "SELECT * FROM notice ORDER BY idx DESC LIMIT ?,?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, currpage);
			pstmt.setInt(2, pageSize);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				noticeDTO dto = new noticeDTO();
				dto.setIdx(rs.getInt(1));
				dto.setTitle(rs.getString(2));
				dto.setContent(rs.getString(3));
				dto.setWrite_date(rs.getString(4));
				v.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		return v;
	}

	public int selectCnt() {
		try {
			conn = pool.getConnection();
			String sql = "SELECT count(*) from notice";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				result = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		return result;
	}

	public int noticeWriteProc(String title, String content) {
		try {
			conn = pool.getConnection();
			String query = "INSERT INTO notice VALUES(null,?,?,curdate())";
			pstmt = conn.prepareStatement(query);

			pstmt.setString(1, title);
			pstmt.setString(2, content);
			System.out.println(title + "/" + content);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}
		return result;
	}

	public noticeDTO selectOne(String idx) {
		noticeDTO dto = new noticeDTO();
		try {
			conn = pool.getConnection();
			String sql = "SELECT * FROM notice WHERE idx=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(idx));
			rs = pstmt.executeQuery();

			if (rs.next()) {
				dto.setIdx(rs.getInt(1));
				dto.setTitle(rs.getString(2));
				dto.setContent(rs.getString(3));
				dto.setWrite_date(rs.getString(4));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		return dto;
	}

	public int noticeUpdateProc(String idx, String title, String content) {
		try {
			conn = pool.getConnection();
			String query = "UPDATE notice set title=?, content=? where idx=?";
			pstmt = conn.prepareStatement(query);

			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setInt(3, Integer.parseInt(idx));
			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}
		return result;
	}

	public int selectDelete(String idx) {
		try {
			conn = pool.getConnection();
			String query = "DELETE FROM notice WHERE idx=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, Integer.parseInt(idx));
			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}
		return result;
	}

	public Vector<noticeDTO> selectAny() {
		// TODO Auto-generated method stub
		Vector<noticeDTO> vector = new Vector<>();
		
		try {
			conn = pool.getConnection();
			String sql = "SELECT * FROM notice ORDER BY idx DESC LIMIT ?, ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, 0);
			pstmt.setInt(2, 6);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				noticeDTO dto = new noticeDTO();
				dto.setIdx(rs.getInt(1));
				dto.setTitle(rs.getString(2));
				dto.setContent(rs.getString(3));
				dto.setWrite_date(rs.getString(4));
				
				vector.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return vector;
	}
}