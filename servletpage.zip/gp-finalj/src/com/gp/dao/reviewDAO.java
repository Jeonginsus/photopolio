package com.gp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import com.gp.dto.reviewDTO;

public class reviewDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	int result = 0;
	DBConnectionMgr pool = DBConnectionMgr.getInstance();

	public Vector<reviewDTO> review_Select() {
		Vector<reviewDTO> v = new Vector<>();
		try {
			conn = pool.getConnection();
			String sql = "select * from review";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				reviewDTO dto = new reviewDTO();
				dto.setIdx(rs.getInt(1));
				dto.setProduct_idx(rs.getInt(2));
				dto.setMember_idx(rs.getInt(3));
				dto.setContent(rs.getString(4));
				dto.setWrite_date(rs.getString(5));
				v.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}

		return v;
	}

	public int review_Delete(String idx) {
		try {
			conn = pool.getConnection();
			String sql = "delete from review where idx=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(idx));
			result = pstmt.executeUpdate();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}

		return result;
	}
	
	public int insert(int product_idx, int member_idx, String review) {
		try {
			conn = pool.getConnection();
			String sql = "insert into review(product_idx, member_idx, content) values(?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, product_idx);
			pstmt.setInt(2, member_idx);
			pstmt.setString(3, review);
			result = pstmt.executeUpdate();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}

		return result;
	}

	public int selectCnt(int idx) {
		// TODO Auto-generated method stub
		try {
			conn = pool.getConnection();
			String sql = "select count(*) from review where product_idx=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				result = rs.getInt(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return result;
	}

	public Vector<reviewDTO> selectAny(int idx) {
		// TODO Auto-generated method stub
		Vector<reviewDTO> v = new Vector<>();
		try {
			conn = pool.getConnection();
			String sql = "select * from review where product_idx=? order by idx desc limit 0, 3";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				reviewDTO dto = new reviewDTO();
				dto.setIdx(rs.getInt("idx"));
				dto.setProduct_idx(rs.getInt("product_idx"));
				dto.setMember_idx(rs.getInt("member_idx"));
				dto.setContent(rs.getString("content"));
				dto.setWrite_date(rs.getString(5));
				v.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt,rs);
		}

		return v;
	}
}