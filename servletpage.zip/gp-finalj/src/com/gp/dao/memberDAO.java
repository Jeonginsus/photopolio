package com.gp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import com.gp.dto.memberDTO;


public class memberDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	int result = 0;
	DBConnectionMgr pool = DBConnectionMgr.getInstance();

	public Vector<memberDTO> selectAll() {
		Vector<memberDTO> v = new Vector<>();
		try {
			conn = pool.getConnection();
			String sql = "select * from member";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				memberDTO dto = new memberDTO();
				dto.setIdx(rs.getInt(1));
				dto.setEmail(rs.getString(2));
				dto.setPassword(rs.getString(3));
				dto.setName(rs.getString(4));
				dto.setPhone(rs.getString(5));
				dto.setEvent(rs.getInt(6));
				
				v.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		return v;
	}
	
	public int insert(memberDTO dto) {
		try {
			conn = pool.getConnection();

			String query = "INSERT INTO member(email, password, name, rank, phone, event) VALUES(?,?,?,?,?,?)";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, dto.getEmail());
			pstmt.setString(2, dto.getPassword());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, "user"); // rank : 일반회원
			pstmt.setString(5, dto.getPhone());
			pstmt.setInt(6, dto.getEvent());
			
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt);
		}
		
		return result;
	}
	
	public int login(memberDTO dto) {
		try {
			conn = pool.getConnection();

			String query = "select count(*) from member where email=? and password=?";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, dto.getEmail());
			pstmt.setString(2, dto.getPassword());

			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				result = rs.getInt(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}

		return result;
	}
	
	public Vector<memberDTO> logindata(String email) {
		Vector<memberDTO> v = new Vector<>();
		
		try {
			conn = pool.getConnection();

			String query = "select * from member where email=?";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, email);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				memberDTO dto = new memberDTO();
				dto.setIdx(rs.getInt(1));
				dto.setEmail(rs.getString(2));
				dto.setPassword(rs.getString(3));
				dto.setName(rs.getString(4));
				dto.setRank(rs.getString(5));
				dto.setPhone(rs.getString(6));
				dto.setEvent(rs.getInt(7));
				dto.setBank(rs.getString(8));
				dto.setAccount(rs.getString(9));
				
				v.add(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}

		return v;
	}

	public int member_update(memberDTO dto) {
		// TODO Auto-generated method stub
		try {
			conn = pool.getConnection();

			String query = "update member set password=?, phone=?, bank=?, account=? where email=?";
			
			pstmt = conn.prepareStatement(query);
			
			pstmt.setString(1, dto.getPassword());
			pstmt.setString(2, dto.getPhone());
			pstmt.setString(3, dto.getBank());
			pstmt.setString(4, dto.getAccount());
			pstmt.setString(5, dto.getEmail());
			
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return result;
	}
	
	public String getRank(memberDTO dto) {
		// TODO Auto-generated method stub
		String rank = "";
		
		try {
			conn = pool.getConnection();

			String query = "select * from member where email=?";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, dto.getEmail());
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				rank = rs.getString(5);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		return rank;
	}
	
	public String getName(int idx) {
		String name = "";
		
		try {
			conn = pool.getConnection();

			String query = "select * from member where idx=?";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, idx);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				name = rs.getString(5);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return name;
	}
	
	public int getIdx(String email) {
		int idx = -1;
		
		try {
			conn = pool.getConnection();

			String query = "select * from member where email=?";
			
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, email);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				idx = rs.getInt(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pool.freeConnection(conn, pstmt, rs);
		}
		
		return idx;
	}
}